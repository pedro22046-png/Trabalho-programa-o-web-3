# Ammo Nation — Como rodar o sistema de pedidos 🔫

Este é o **backend + telas** do sistema de pedidos (CodeIgniter 4 + PHP + JavaScript),
usando o **Supabase (PostgreSQL)** como banco de dados.

O projeto tem 4 partes:
- **Cliente/Totem** → escolher produtos, carrinho, checkout e nota do pedido
- **Cozinha** → ver pedidos e mudar o status (preparando / pronto / cancelar)
- **Painel** → login, controle de usuários, painel de consumo e painel de vendas
- **Totens** → cada totem se identifica ao iniciar um pedido

---

## 1. O que precisa estar instalado

- **PHP 8.2+** com a extensão **pgsql** ligada (o XAMPP já tem; eu ativei no seu `php.ini`).
- O banco no **Supabase** (já configurado no `.env`).

Confira o PHP e a extensão:
```bash
php -v
php -m | findstr pgsql
```
Tem que aparecer `pgsql` e `pdo_pgsql`.

---

## 2. Preparar o banco (só na primeira vez)

Dentro da pasta do projeto, rode:
```bash
php spark setup
```
Isso cria as tabelas no Supabase e cadastra:
- 6 produtos (as armas)
- 2 totens (Totem 1 e Totem 2)
- 1 super admin

Pode rodar de novo quando quiser — não duplica nada.

> Se preferir, o SQL das tabelas também está em [`supabase_setup.sql`](supabase_setup.sql)
> para colar no **SQL Editor** do Supabase.

---

## 3. Rodar o servidor

```bash
php spark serve
```
Vai abrir em **http://localhost:8080**

- **Totem (cliente):** http://localhost:8080/
- **Cozinha:** http://localhost:8080/cozinha-pedidos.html
- **Painel (funcionários):** http://localhost:8080/painel/login

---

## 4. Login do painel

| Campo | Valor |
|-------|-------|
| Email | `admin@admin.com` |
| Senha | `admin123` |

> Troque a senha depois em **Meus dados**. Como Super Admin você também cria
> outros usuários em **Usuários**.

---

## Como testar tudo (roteiro da apresentação)

1. **Totem:** abra `/`, escolha um totem, clique em **Iniciar Pedido**.
2. **Produtos:** filtre por categoria e clique em **Adicionar** em alguns produtos.
3. **Carrinho:** ajuste as quantidades (+/−), remova um item, clique em **Confirmar**.
4. **Checkout:** confira o resumo e clique em **Finalizar Pedido**.
5. **Nota:** aparece o **número do pedido** (gerado pelo backend).
6. **Cozinha:** abra `/cozinha-pedidos.html` — o pedido aparece lá.
   Clique nele e mude o status para **Preparando** e depois **Pronto**.
7. **Painel:** entre em `/painel/login`.
   - **Painel de consumo:** veja o estoque e quanto cada produto vendeu.
   - **Painel de vendas:** veja o gráfico e a tabela por dia.
   - **Usuários:** crie, edite, bloqueie/desbloqueie usuários.
   - **Totens:** cadastre e remova totens.

---

## Detalhes técnicos

- A conexão com o Supabase está no `.env` (chaves `database.default.*`).
- O código dos endpoints está em `app/Controllers/Api.php`.
- O painel está em `app/Controllers/` (`Auth`, `Painel`, `Usuarios`, `Totens`)
  e as telas em `app/Views/painel/`.
- As telas do cliente e da cozinha são arquivos em `public/` (HTML + JS puro).
