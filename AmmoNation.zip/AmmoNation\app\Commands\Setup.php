<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Config\Database;
use App\Models\ProdutoModel;
use App\Models\TotemModel;
use App\Models\UsuarioModel;

/**
 * Comando: php spark setup
 *
 * Cria as tabelas no Supabase (rodando o supabase_setup.sql) e popula
 * os dados iniciais: produtos (armas), totens e o super admin.
 * Pode rodar quantas vezes quiser, nao duplica nada.
 */
class Setup extends BaseCommand
{
    protected $group       = 'Ammo Nation';
    protected $name        = 'setup';
    protected $description = 'Cria as tabelas no Supabase e popula produtos, totens e super admin.';

    public function run(array $params)
    {
        CLI::write('Conectando no Supabase...', 'yellow');

        $db = Database::connect();

        try {
            $db->initialize();
            pg_ping($db->connID);
        } catch (\Throwable $e) {
            CLI::error('Nao consegui conectar no banco: ' . $e->getMessage());
            return;
        }

        // 1) Cria as tabelas (roda o arquivo SQL) --------------------------
        CLI::write('Criando tabelas...', 'yellow');
        $sqlFile = ROOTPATH . 'supabase_setup.sql';
        if (! is_file($sqlFile)) {
            CLI::error('Arquivo supabase_setup.sql nao encontrado em ' . ROOTPATH);
            return;
        }
        $sql = file_get_contents($sqlFile);
        $res = pg_query($db->connID, $sql);
        if ($res === false) {
            CLI::error('Erro ao criar tabelas: ' . pg_last_error($db->connID));
            return;
        }
        CLI::write('  Tabelas OK.', 'green');

        // 2) Produtos (armas) ---------------------------------------------
        $produtoModel = new ProdutoModel();
        if ((int) $produtoModel->countAllResults() === 0) {
            $produtoModel->insertBatch([
                ['nome' => 'Desert Eagle', 'descricao' => 'Pistola de alto calibre com mira precisa.', 'preco' => 1520, 'categoria' => 'Pistola',  'imagem' => 'assets/imagens/desert-eagle.svg'],
                ['nome' => 'AK-47',        'descricao' => 'Rifle robusto para operacoes rapidas.',      'preco' => 2400, 'categoria' => 'Rifle',    'imagem' => 'assets/imagens/ak47.svg'],
                ['nome' => 'M4A1',         'descricao' => 'Rifle leve com excelente controle.',          'preco' => 2750, 'categoria' => 'Rifle',    'imagem' => 'assets/imagens/m4a1.svg'],
                ['nome' => 'Glock 19',     'descricao' => 'Pistola compacta para uso tatico.',           'preco' => 1280, 'categoria' => 'Pistola',  'imagem' => 'assets/imagens/glock19.svg'],
                ['nome' => 'Coletes',      'descricao' => 'Protecao leve para operacoes em campo.',       'preco' => 720,  'categoria' => 'Acessorio','imagem' => 'assets/imagens/coletes.svg'],
                ['nome' => 'Municao 9mm',  'descricao' => 'Cartuchos de uso geral para pistolas.',        'preco' => 230,  'categoria' => 'Acessorio','imagem' => 'assets/imagens/municao-9mm.svg'],
            ]);
            CLI::write('  Produtos criados (6 armas).', 'green');
        } else {
            CLI::write('  Produtos ja existem, pulando.', 'dark_gray');
        }

        // 3) Totens --------------------------------------------------------
        $totemModel = new TotemModel();
        if ((int) $totemModel->countAllResults() === 0) {
            $totemModel->insertBatch([
                ['nome' => 'Totem 1', 'codigo' => 'TOTEM-01'],
                ['nome' => 'Totem 2', 'codigo' => 'TOTEM-02'],
            ]);
            CLI::write('  Totens criados (Totem 1 e 2).', 'green');
        } else {
            CLI::write('  Totens ja existem, pulando.', 'dark_gray');
        }

        // 4) Super admin ---------------------------------------------------
        $usuarioModel = new UsuarioModel();
        if (! $usuarioModel->where('email', 'admin@admin.com')->first()) {
            $usuarioModel->insert([
                'nome'       => 'Administrador',
                'email'      => 'admin@admin.com',
                'senha_hash' => password_hash('admin123', PASSWORD_DEFAULT),
                'papel'      => 'super_admin',
            ]);
            CLI::write('  Super admin criado.', 'green');
        } else {
            CLI::write('  Super admin ja existe, pulando.', 'dark_gray');
        }

        CLI::newLine();
        CLI::write('=====================================================', 'green');
        CLI::write(' Tudo pronto! Login do painel:', 'green');
        CLI::write('   Email: admin@admin.com', 'white');
        CLI::write('   Senha: admin123', 'white');
        CLI::write('=====================================================', 'green');
    }
}
