<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// API Routes (cliente + cozinha)
$routes->get('api/produtos', 'Api::produtos');
$routes->get('api/totens', 'Api::totens');
$routes->post('api/pedidos', 'Api::criarPedido');
$routes->get('api/cozinha/pedidos', 'Api::listaPedidos');
$routes->get('api/cozinha/pedidos/(:num)', 'Api::detalhePedido/$1');
$routes->put('api/cozinha/pedidos/(:num)/status', 'Api::atualizarStatusPedido/$1');

// ---------- Painel (Parte 3) ----------
// Login (aberto)
$routes->get('painel/login', 'Auth::login');
$routes->post('painel/login', 'Auth::processarLogin');
$routes->get('painel/logout', 'Auth::logout');

// Precisa estar logado
$routes->group('painel', ['filter' => 'auth'], static function ($routes) {
    $routes->get('', 'Painel::index');
    $routes->get('consumo', 'Painel::consumo');
    $routes->get('vendas', 'Painel::vendas');
    $routes->get('produtos/toggle/(:num)', 'Painel::toggleProduto/$1');
    $routes->get('perfil', 'Painel::perfil');
    $routes->post('perfil', 'Painel::salvarPerfil');
});

// Somente Super Admin
$routes->group('painel', ['filter' => 'superadmin'], static function ($routes) {
    // Controle de usuarios
    $routes->get('usuarios', 'Usuarios::index');
    $routes->get('usuarios/novo', 'Usuarios::novo');
    $routes->post('usuarios/criar', 'Usuarios::criar');
    $routes->get('usuarios/editar/(:num)', 'Usuarios::editar/$1');
    $routes->post('usuarios/atualizar/(:num)', 'Usuarios::atualizar/$1');
    $routes->get('usuarios/bloquear/(:num)', 'Usuarios::bloquear/$1');
    $routes->get('usuarios/desbloquear/(:num)', 'Usuarios::desbloquear/$1');
    $routes->get('usuarios/excluir/(:num)', 'Usuarios::excluir/$1');
    // Totens
    $routes->get('totens', 'Totens::index');
    $routes->post('totens/criar', 'Totens::criar');
    $routes->get('totens/excluir/(:num)', 'Totens::excluir/$1');
});
