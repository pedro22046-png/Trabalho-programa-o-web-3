<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;
use App\Models\ProdutoModel;
use App\Models\PedidoModel;
use App\Models\ItemPedidoModel;
use App\Models\TotemModel;

class Api extends BaseController
{
    /**
     * Lista os produtos disponiveis (para o cliente montar o pedido).
     */
    public function produtos(): ResponseInterface
    {
        $produtoModel = new ProdutoModel();
        $produtos = $produtoModel
            ->where('disponivel', 'true')
            ->orderBy('id', 'ASC')
            ->findAll();

        // O Postgres devolve tudo como texto; converte para os tipos certos
        // (o frontend compara o id como numero).
        foreach ($produtos as &$p) {
            $p['id']         = (int) $p['id'];
            $p['preco']      = (float) $p['preco'];
            $p['estoque']    = (int) $p['estoque'];
            $p['disponivel'] = ($p['disponivel'] === 't' || $p['disponivel'] === true);
        }

        return $this->response->setJSON($produtos);
    }

    /**
     * Lista os totens cadastrados (para o cliente identificar de qual totem
     * o pedido esta saindo).
     */
    public function totens(): ResponseInterface
    {
        $totemModel = new TotemModel();
        $totens = $totemModel->orderBy('id', 'ASC')->findAll();

        return $this->response->setJSON($totens);
    }

    /**
     * Cria um novo pedido e salva no banco (pedido + itens).
     */
    public function criarPedido(): ResponseInterface
    {
        $json = $this->request->getJSON(true);

        if (empty($json['itens']) || ! is_array($json['itens'])) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['erro' => 'Pedido sem itens']);
        }

        $produtoModel = new ProdutoModel();
        $pedidoModel  = new PedidoModel();
        $itemModel    = new ItemPedidoModel();

        // Monta os itens usando o preco REAL do banco (evita fraude no preco).
        $itensSalvar = [];
        $total       = 0;

        foreach ($json['itens'] as $item) {
            $produtoId = $item['id'] ?? $item['produto_id'] ?? null;
            $qtd       = max(1, (int) ($item['quantidade'] ?? 1));

            $produto = $produtoId ? $produtoModel->find($produtoId) : null;

            $nome  = $produto['nome']  ?? ($item['nome'] ?? 'Item');
            $preco = $produto ? (float) $produto['preco'] : (float) ($item['preco'] ?? 0);

            $total += $preco * $qtd;

            $itensSalvar[] = [
                'produto_id' => $produto['id'] ?? null,
                'nome'       => $nome,
                'preco'      => $preco,
                'quantidade' => $qtd,
            ];
        }

        // Cria o pedido
        $totemId = ! empty($json['totem_id']) ? (int) $json['totem_id'] : null;

        $pedidoId = $pedidoModel->insert([
            'numero'   => null,
            'totem_id' => $totemId,
            'status'   => 'recebido',
            'total'    => $total,
        ], true);

        if (! $pedidoId) {
            return $this->response
                ->setStatusCode(500)
                ->setJSON(['erro' => 'Nao foi possivel salvar o pedido']);
        }

        // Numero do pedido = id com 3 digitos (ex.: 005)
        $numero = str_pad((string) $pedidoId, 3, '0', STR_PAD_LEFT);
        $pedidoModel->update($pedidoId, ['numero' => $numero]);

        // Salva os itens
        foreach ($itensSalvar as &$i) {
            $i['pedido_id'] = $pedidoId;
        }
        $itemModel->insertBatch($itensSalvar);

        return $this->response
            ->setStatusCode(201)
            ->setJSON($this->montarPedido($pedidoId));
    }

    /**
     * Lista todos os pedidos (tela da cozinha), mais recentes primeiro.
     */
    public function listaPedidos(): ResponseInterface
    {
        $pedidoModel = new PedidoModel();
        $pedidos = $pedidoModel->orderBy('created_at', 'DESC')->findAll();

        $resultado = [];
        foreach ($pedidos as $pedido) {
            $resultado[] = $this->montarPedido($pedido['id'], $pedido);
        }

        return $this->response->setJSON($resultado);
    }

    /**
     * Detalhes de um pedido especifico.
     */
    public function detalhePedido($id = null): ResponseInterface
    {
        $pedidoModel = new PedidoModel();
        $pedido = $pedidoModel->find((int) $id);

        if (! $pedido) {
            return $this->response
                ->setStatusCode(404)
                ->setJSON(['erro' => 'Pedido nao encontrado']);
        }

        return $this->response->setJSON($this->montarPedido($pedido['id'], $pedido));
    }

    /**
     * Atualiza o status de um pedido (preparando / pronto / cancelado).
     */
    public function atualizarStatusPedido($id = null): ResponseInterface
    {
        $json = $this->request->getJSON(true);

        $statusValidos = ['recebido', 'preparando', 'pronto', 'cancelado'];
        $novoStatus    = $json['status'] ?? null;

        if (! in_array($novoStatus, $statusValidos, true)) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['erro' => 'Status invalido']);
        }

        $pedidoModel = new PedidoModel();
        $pedido = $pedidoModel->find((int) $id);

        if (! $pedido) {
            return $this->response
                ->setStatusCode(404)
                ->setJSON(['erro' => 'Pedido nao encontrado']);
        }

        $pedidoModel->update((int) $id, ['status' => $novoStatus]);

        return $this->response->setJSON($this->montarPedido((int) $id));
    }

    /**
     * Monta o array de um pedido com seus itens, no formato que o frontend usa.
     */
    private function montarPedido(int $pedidoId, ?array $pedido = null): array
    {
        $pedidoModel = new PedidoModel();
        $itemModel   = new ItemPedidoModel();

        if ($pedido === null) {
            $pedido = $pedidoModel->find($pedidoId);
        }

        $itens = $itemModel
            ->where('pedido_id', $pedidoId)
            ->orderBy('id', 'ASC')
            ->findAll();

        foreach ($itens as &$i) {
            $i['preco']      = (float) $i['preco'];
            $i['quantidade'] = (int) $i['quantidade'];
        }

        return [
            'id'       => (int) $pedido['id'],
            'numero'   => $pedido['numero'] ?? str_pad((string) $pedido['id'], 3, '0', STR_PAD_LEFT),
            'status'   => $pedido['status'],
            'total'    => (float) $pedido['total'],
            'totem_id' => $pedido['totem_id'] !== null ? (int) $pedido['totem_id'] : null,
            'data'     => $pedido['created_at'],
            'itens'    => $itens,
        ];
    }
}
