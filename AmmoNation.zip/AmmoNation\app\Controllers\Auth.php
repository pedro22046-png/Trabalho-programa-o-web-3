<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class Auth extends BaseController
{
    /**
     * Mostra a tela de login. Se ja estiver logado, vai direto pro painel.
     */
    public function login()
    {
        if (session()->get('usuario_id')) {
            return redirect()->to('/painel');
        }

        return view('painel/login');
    }

    /**
     * Processa o login (email + senha).
     */
    public function processarLogin()
    {
        $email = trim((string) $this->request->getPost('email'));
        $senha = (string) $this->request->getPost('senha');

        $usuarioModel = new UsuarioModel();
        $usuario = $usuarioModel->where('email', $email)->first();

        if (! $usuario || ! password_verify($senha, $usuario['senha_hash'])) {
            return redirect()->back()
                ->withInput()
                ->with('erro', 'Email ou senha incorretos.');
        }

        if ($usuario['bloqueado'] === true || $usuario['bloqueado'] === 't') {
            return redirect()->back()
                ->with('erro', 'Seu usuario esta bloqueado. Fale com o administrador.');
        }

        // Guarda o usuario na sessao
        session()->set([
            'usuario_id'    => (int) $usuario['id'],
            'usuario_nome'  => $usuario['nome'],
            'usuario_email' => $usuario['email'],
            'usuario_papel' => $usuario['papel'],
        ]);

        return redirect()->to('/painel');
    }

    /**
     * Sai da conta.
     */
    public function logout()
    {
        session()->destroy();

        return redirect()->to('/painel/login');
    }
}
