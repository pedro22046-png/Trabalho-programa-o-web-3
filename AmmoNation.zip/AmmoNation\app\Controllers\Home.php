<?php

namespace App\Controllers;

class Home extends BaseController
{
    /**
     * A raiz "/" abre a tela inicial do totem (public/index.html).
     */
    public function index(): string
    {
        return file_get_contents(FCPATH . 'index.html');
    }
}
