<?php

namespace App\Controllers;

use App\Models\ProdutoModel;
use App\Models\PedidoModel;
use App\Models\UsuarioModel;
use Config\Database;

class Painel extends BaseController
{
    /**
     * Dashboard inicial do painel.
     */
    public function index()
    {
        $db = Database::connect();

        $totalPedidos = (new PedidoModel())->countAllResults();
        $totalProdutos = (new ProdutoModel())->countAllResults();
        $totalUsuarios = (new UsuarioModel())->countAllResults();

        $vendasHoje = $db->query(
            "select coalesce(sum(total), 0) as v from pedidos
             where status <> 'cancelado' and created_at::date = current_date"
        )->getRow()->v;

        $pendentes = $db->query(
            "select count(*) as c from pedidos where status in ('recebido','preparando')"
        )->getRow()->c;

        return view('painel/dashboard', [
            'totalPedidos'  => $totalPedidos,
            'totalProdutos' => $totalProdutos,
            'totalUsuarios' => $totalUsuarios,
            'vendasHoje'    => (float) $vendasHoje,
            'pendentes'     => (int) $pendentes,
        ]);
    }

    /**
     * Painel de consumo: produtos com estoque e quantidade consumida.
     */
    public function consumo()
    {
        $db = Database::connect();

        $produtos = $db->query(
            "select p.id, p.nome, p.categoria, p.disponivel, p.estoque,
                coalesce((
                    select sum(i.quantidade)
                    from itens_pedido i
                    join pedidos ped on ped.id = i.pedido_id
                    where i.produto_id = p.id and ped.status <> 'cancelado'
                ), 0) as quantidade
             from produtos p
             order by p.id"
        )->getResultArray();

        // Lista de categorias para o filtro
        $categorias = $db->query(
            "select distinct categoria from produtos where categoria is not null order by categoria"
        )->getResultArray();

        return view('painel/consumo', [
            'produtos'   => $produtos,
            'categorias' => array_column($categorias, 'categoria'),
        ]);
    }

    /**
     * Liga/desliga a disponibilidade de um produto.
     */
    public function toggleProduto($id = null)
    {
        $produtoModel = new ProdutoModel();
        $produto = $produtoModel->find((int) $id);

        if ($produto) {
            $ativo = ($produto['disponivel'] === 't' || $produto['disponivel'] === true);
            $produtoModel->update((int) $id, ['disponivel' => $ativo ? 'false' : 'true']);
        }

        return redirect()->to('/painel/consumo');
    }

    /**
     * Painel de vendas: tabela por dia + dados para o grafico.
     */
    public function vendas()
    {
        $db = Database::connect();

        $dias = (int) ($this->request->getGet('dias') ?? 7);
        if (! in_array($dias, [7, 15, 30], true)) {
            $dias = 7;
        }

        // Vendas por dia (todas), mais recentes primeiro (para a tabela)
        $porDia = $db->query(
            "select to_char(created_at::date, 'YYYY-MM-DD') as dia, sum(total) as valor
             from pedidos
             where status <> 'cancelado'
             group by created_at::date
             order by created_at::date desc"
        )->getResultArray();

        // Mapa dia => valor
        $mapa = [];
        foreach ($porDia as $linha) {
            $mapa[$linha['dia']] = (float) $linha['valor'];
        }

        // Monta a serie dos ultimos N dias (preenchendo zeros)
        $labels = [];
        $valores = [];
        for ($i = $dias - 1; $i >= 0; $i--) {
            $data = date('Y-m-d', strtotime("-{$i} days"));
            $labels[] = date('d/m', strtotime($data));
            $valores[] = $mapa[$data] ?? 0;
        }

        return view('painel/vendas', [
            'porDia'  => $porDia,
            'labels'  => $labels,
            'valores' => $valores,
            'dias'    => $dias,
        ]);
    }

    /**
     * Cada usuario pode editar os proprios dados.
     */
    public function perfil()
    {
        $usuarioModel = new UsuarioModel();
        $usuario = $usuarioModel->find(session()->get('usuario_id'));

        return view('painel/perfil', ['usuario' => $usuario]);
    }

    public function salvarPerfil()
    {
        $id = session()->get('usuario_id');
        $usuarioModel = new UsuarioModel();
        $usuario = $usuarioModel->find($id);

        if (! $usuario) {
            return redirect()->to('/painel/login');
        }

        $nome  = trim((string) $this->request->getPost('nome'));
        $email = trim((string) $this->request->getPost('email'));
        $senha = (string) $this->request->getPost('senha');

        if ($nome === '' || $email === '') {
            return redirect()->back()->with('erro', 'Nome e email sao obrigatorios.');
        }

        // Email nao pode repetir de outro usuario
        $existe = $usuarioModel->where('email', $email)->where('id !=', $id)->first();
        if ($existe) {
            return redirect()->back()->with('erro', 'Esse email ja esta em uso.');
        }

        $dados = ['nome' => $nome, 'email' => $email];
        if ($senha !== '') {
            $dados['senha_hash'] = password_hash($senha, PASSWORD_DEFAULT);
        }

        $usuarioModel->update($id, $dados);

        // Atualiza a sessao (nome/email podem ter mudado)
        session()->set([
            'usuario_nome'  => $nome,
            'usuario_email' => $email,
        ]);

        return redirect()->to('/painel/perfil')->with('sucesso', 'Dados atualizados!');
    }
}
