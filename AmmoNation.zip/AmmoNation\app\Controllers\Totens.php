<?php

namespace App\Controllers;

use App\Models\TotemModel;

class Totens extends BaseController
{
    public function index()
    {
        $totens = (new TotemModel())->orderBy('id', 'ASC')->findAll();

        return view('painel/totens/index', ['totens' => $totens]);
    }

    public function criar()
    {
        $nome   = trim((string) $this->request->getPost('nome'));
        $codigo = trim((string) $this->request->getPost('codigo'));

        if ($nome === '' || $codigo === '') {
            return redirect()->back()->with('erro', 'Preencha nome e codigo do totem.');
        }

        $model = new TotemModel();
        if ($model->where('codigo', $codigo)->first()) {
            return redirect()->back()->with('erro', 'Ja existe um totem com esse codigo.');
        }

        $model->insert(['nome' => $nome, 'codigo' => $codigo]);

        return redirect()->to('/painel/totens')->with('sucesso', 'Totem cadastrado!');
    }

    public function excluir($id = null)
    {
        (new TotemModel())->delete((int) $id);

        return redirect()->to('/painel/totens')->with('sucesso', 'Totem excluido.');
    }
}
