<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class Usuarios extends BaseController
{
    private function model(): UsuarioModel
    {
        return new UsuarioModel();
    }

    /**
     * Lista todos os usuarios.
     */
    public function index()
    {
        $usuarios = $this->model()->orderBy('id', 'ASC')->findAll();

        return view('painel/usuarios/index', ['usuarios' => $usuarios]);
    }

    /**
     * Formulario de novo usuario.
     */
    public function novo()
    {
        return view('painel/usuarios/form', [
            'usuario' => null,
            'titulo'  => 'Novo usuario',
        ]);
    }

    /**
     * Salva um novo usuario.
     */
    public function criar()
    {
        $nome  = trim((string) $this->request->getPost('nome'));
        $email = trim((string) $this->request->getPost('email'));
        $senha = (string) $this->request->getPost('senha');
        $papel = $this->request->getPost('papel') === 'super_admin' ? 'super_admin' : 'usuario';

        if ($nome === '' || $email === '' || $senha === '') {
            return redirect()->back()->withInput()->with('erro', 'Preencha nome, email e senha.');
        }

        if ($this->model()->where('email', $email)->first()) {
            return redirect()->back()->withInput()->with('erro', 'Esse email ja esta cadastrado.');
        }

        $this->model()->insert([
            'nome'       => $nome,
            'email'      => $email,
            'senha_hash' => password_hash($senha, PASSWORD_DEFAULT),
            'papel'      => $papel,
        ]);

        return redirect()->to('/painel/usuarios')->with('sucesso', 'Usuario criado!');
    }

    /**
     * Formulario de edicao.
     */
    public function editar($id = null)
    {
        $usuario = $this->model()->find((int) $id);
        if (! $usuario) {
            return redirect()->to('/painel/usuarios')->with('erro', 'Usuario nao encontrado.');
        }

        return view('painel/usuarios/form', [
            'usuario' => $usuario,
            'titulo'  => 'Editar usuario',
        ]);
    }

    /**
     * Atualiza um usuario.
     */
    public function atualizar($id = null)
    {
        $usuario = $this->model()->find((int) $id);
        if (! $usuario) {
            return redirect()->to('/painel/usuarios')->with('erro', 'Usuario nao encontrado.');
        }

        $nome  = trim((string) $this->request->getPost('nome'));
        $email = trim((string) $this->request->getPost('email'));
        $senha = (string) $this->request->getPost('senha');
        $papel = $this->request->getPost('papel') === 'super_admin' ? 'super_admin' : 'usuario';

        if ($nome === '' || $email === '') {
            return redirect()->back()->withInput()->with('erro', 'Nome e email sao obrigatorios.');
        }

        if ($this->model()->where('email', $email)->where('id !=', (int) $id)->first()) {
            return redirect()->back()->withInput()->with('erro', 'Esse email ja esta em uso.');
        }

        $dados = ['nome' => $nome, 'email' => $email, 'papel' => $papel];
        if ($senha !== '') {
            $dados['senha_hash'] = password_hash($senha, PASSWORD_DEFAULT);
        }

        $this->model()->update((int) $id, $dados);

        return redirect()->to('/painel/usuarios')->with('sucesso', 'Usuario atualizado!');
    }

    public function bloquear($id = null)
    {
        return $this->mudarBloqueio((int) $id, true);
    }

    public function desbloquear($id = null)
    {
        return $this->mudarBloqueio((int) $id, false);
    }

    private function mudarBloqueio(int $id, bool $bloquear)
    {
        $usuario = $this->model()->find($id);
        if (! $usuario) {
            return redirect()->to('/painel/usuarios')->with('erro', 'Usuario nao encontrado.');
        }

        // Nao deixa o admin bloquear a si mesmo
        if ($id === (int) session()->get('usuario_id')) {
            return redirect()->to('/painel/usuarios')->with('erro', 'Voce nao pode bloquear a si mesmo.');
        }

        $this->model()->update($id, ['bloqueado' => $bloquear ? 'true' : 'false']);

        return redirect()->to('/painel/usuarios')
            ->with('sucesso', $bloquear ? 'Usuario bloqueado.' : 'Usuario desbloqueado.');
    }

    public function excluir($id = null)
    {
        $id = (int) $id;

        if ($id === (int) session()->get('usuario_id')) {
            return redirect()->to('/painel/usuarios')->with('erro', 'Voce nao pode excluir a si mesmo.');
        }

        $this->model()->delete($id);

        return redirect()->to('/painel/usuarios')->with('sucesso', 'Usuario excluido.');
    }
}
