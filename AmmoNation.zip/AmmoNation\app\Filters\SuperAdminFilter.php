<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Deixa passar so o Super Admin. Usuario comum vai pro painel com aviso.
 */
class SuperAdminFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! session()->get('usuario_id')) {
            return redirect()->to('/painel/login');
        }

        if (session()->get('usuario_papel') !== 'super_admin') {
            return redirect()->to('/painel')
                ->with('erro', 'Apenas o Super Admin pode acessar essa area.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // nada
    }
}
