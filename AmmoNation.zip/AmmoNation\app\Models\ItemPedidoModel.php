<?php

namespace App\Models;

use CodeIgniter\Model;

class ItemPedidoModel extends Model
{
    protected $table            = 'itens_pedido';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'pedido_id',
        'produto_id',
        'nome',
        'preco',
        'quantidade',
    ];
}
