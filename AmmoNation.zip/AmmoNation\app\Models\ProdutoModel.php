<?php

namespace App\Models;

use CodeIgniter\Model;

class ProdutoModel extends Model
{
    protected $table            = 'produtos';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'nome',
        'descricao',
        'preco',
        'categoria',
        'imagem',
        'disponivel',
        'estoque',
    ];
}
