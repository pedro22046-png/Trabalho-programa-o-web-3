<?php

namespace App\Models;

use CodeIgniter\Model;

class TotemModel extends Model
{
    protected $table            = 'totens';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $allowedFields    = [
        'nome',
        'codigo',
    ];
}
