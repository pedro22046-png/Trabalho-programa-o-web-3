<?php $titulo = 'Painel de consumo'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<div class="panel">
  <div class="filter-bar">
    <label>
      Categoria:
      <select id="filtro-categoria">
        <option value="">Todas</option>
        <?php foreach ($categorias as $cat): ?>
          <option value="<?= esc($cat) ?>"><?= esc($cat) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <input type="text" id="filtro-busca" placeholder="Filtrar por nome..." />
  </div>

  <table class="data" id="tabela-consumo">
    <thead>
      <tr>
        <th>Produto</th>
        <th>Categoria</th>
        <th>Disponivel</th>
        <th>Stock atual</th>
        <th>Quantidade vendida</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($produtos as $p): ?>
        <?php $ativo = ($p['disponivel'] === 't' || $p['disponivel'] === true); ?>
        <tr data-categoria="<?= esc($p['categoria']) ?>" data-nome="<?= esc(strtolower($p['nome'])) ?>">
          <td><strong><?= esc($p['nome']) ?></strong></td>
          <td><?= esc($p['categoria']) ?></td>
          <td>
            <span class="badge <?= $ativo ? 'badge-sim' : 'badge-nao' ?>">
              <?= $ativo ? 'Sim' : 'Nao' ?>
            </span>
          </td>
          <td><?= (int) $p['estoque'] ?></td>
          <td><?= (int) $p['quantidade'] ?></td>
          <td>
            <a class="btn btn-sm <?= $ativo ? 'btn-danger' : 'btn-success' ?>"
               href="<?= base_url('painel/produtos/toggle/' . $p['id']) ?>">
              <?= $ativo ? 'Desativar' : 'Ativar' ?>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script>
  const filtroCategoria = document.getElementById('filtro-categoria');
  const filtroBusca = document.getElementById('filtro-busca');
  const linhas = Array.from(document.querySelectorAll('#tabela-consumo tbody tr'));

  function aplicarFiltro() {
    const cat = filtroCategoria.value;
    const busca = filtroBusca.value.toLowerCase();
    linhas.forEach((tr) => {
      const okCat = !cat || tr.dataset.categoria === cat;
      const okBusca = !busca || tr.dataset.nome.includes(busca);
      tr.style.display = okCat && okBusca ? '' : 'none';
    });
  }

  filtroCategoria.addEventListener('change', aplicarFiltro);
  filtroBusca.addEventListener('input', aplicarFiltro);
</script>

<?= $this->endSection() ?>
