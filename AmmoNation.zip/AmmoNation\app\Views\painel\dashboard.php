<?php $titulo = 'Dashboard'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<div class="cards">
  <div class="card">
    <div class="label">Vendas de hoje</div>
    <div class="value"><?= 'R$ ' . number_format($vendasHoje, 2, ',', '.') ?></div>
  </div>
  <div class="card">
    <div class="label">Pedidos na fila</div>
    <div class="value"><?= (int) $pendentes ?></div>
  </div>
  <div class="card">
    <div class="label">Total de pedidos</div>
    <div class="value"><?= (int) $totalPedidos ?></div>
  </div>
  <div class="card">
    <div class="label">Produtos</div>
    <div class="value"><?= (int) $totalProdutos ?></div>
  </div>
  <div class="card">
    <div class="label">Usuarios</div>
    <div class="value"><?= (int) $totalUsuarios ?></div>
  </div>
</div>

<div class="panel">
  <h2>Atalhos</h2>
  <div class="btn-row">
    <a class="btn btn-secondary" href="<?= base_url('painel/consumo') ?>">Ver consumo</a>
    <a class="btn btn-secondary" href="<?= base_url('painel/vendas') ?>">Ver vendas</a>
    <a class="btn btn-secondary" href="<?= base_url('cozinha-pedidos.html') ?>" target="_blank">Abrir cozinha</a>
    <a class="btn btn-secondary" href="<?= base_url('/') ?>" target="_blank">Abrir totem</a>
  </div>
</div>

<?= $this->endSection() ?>
