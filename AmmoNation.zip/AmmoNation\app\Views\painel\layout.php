<?php
$uri   = uri_string(); // ex.: painel/consumo
$papel = session()->get('usuario_papel');
$isAdmin = ($papel === 'super_admin');

function navAtivo(string $rota, string $uri): string
{
    // combina exatamente ou pelo comeco (ex.: painel/usuarios/novo)
    if ($rota === 'painel') {
        return $uri === 'painel' ? 'active' : '';
    }
    return str_starts_with($uri, $rota) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= esc($titulo ?? 'Painel') ?> - Ammo Nation</title>
  <link rel="stylesheet" href="<?= base_url('css/painel.css') ?>" />
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand">
        <div class="logo">A</div>
        <div>
          <strong>Ammo Nation</strong><br />
          <span style="font-size:0.75rem;color:#7a80a8;">Painel</span>
        </div>
      </div>

      <a class="nav-link <?= navAtivo('painel', $uri) ?>" href="<?= base_url('painel') ?>">Dashboard</a>
      <a class="nav-link <?= navAtivo('painel/consumo', $uri) ?>" href="<?= base_url('painel/consumo') ?>">Painel de consumo</a>
      <a class="nav-link <?= navAtivo('painel/vendas', $uri) ?>" href="<?= base_url('painel/vendas') ?>">Painel de vendas</a>

      <?php if ($isAdmin): ?>
        <div class="nav-sep">Administracao</div>
        <a class="nav-link <?= navAtivo('painel/usuarios', $uri) ?>" href="<?= base_url('painel/usuarios') ?>">Usuarios</a>
        <a class="nav-link <?= navAtivo('painel/totens', $uri) ?>" href="<?= base_url('painel/totens') ?>">Totens</a>
      <?php endif; ?>

      <div class="nav-sep">Conta</div>
      <a class="nav-link <?= navAtivo('painel/perfil', $uri) ?>" href="<?= base_url('painel/perfil') ?>">Meus dados</a>

      <div class="spacer"></div>
      <a class="nav-link" href="<?= base_url('painel/logout') ?>">Sair</a>
    </aside>

    <main class="main">
      <div class="topbar">
        <h1><?= esc($titulo ?? 'Painel') ?></h1>
        <div class="user-chip">
          <?= esc(session()->get('usuario_nome')) ?>
          &middot; <strong><?= $isAdmin ? 'Super Admin' : 'Usuario' ?></strong>
        </div>
      </div>

      <?php if (session()->getFlashdata('sucesso')): ?>
        <div class="alert alert-sucesso"><?= esc(session()->getFlashdata('sucesso')) ?></div>
      <?php endif; ?>
      <?php if (session()->getFlashdata('erro')): ?>
        <div class="alert alert-erro"><?= esc(session()->getFlashdata('erro')) ?></div>
      <?php endif; ?>

      <?= $this->renderSection('conteudo') ?>
    </main>
  </div>
</body>
</html>
