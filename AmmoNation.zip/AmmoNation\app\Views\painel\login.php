<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - Ammo Nation</title>
  <link rel="stylesheet" href="<?= base_url('css/painel.css') ?>" />
</head>
<body>
  <div class="login-wrap">
    <form class="login-card" method="post" action="<?= base_url('painel/login') ?>">
      <div class="login-logo">A</div>
      <h2 style="text-align:center;margin:0 0 6px;">Painel Ammo Nation</h2>
      <p style="text-align:center;color:var(--text-muted);margin:0 0 22px;">Entre com seu usuario</p>

      <?php if (session()->getFlashdata('erro')): ?>
        <div class="alert alert-erro"><?= esc(session()->getFlashdata('erro')) ?></div>
      <?php endif; ?>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= esc(old('email')) ?>" required />
      </div>
      <div class="form-group">
        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required />
      </div>

      <button type="submit" class="btn btn-primary btn-full">Entrar</button>

      <p style="text-align:center;margin-top:18px;">
        <a href="<?= base_url('/') ?>" style="color:var(--text-muted);">Voltar ao totem</a>
      </p>
    </form>
  </div>
</body>
</html>
