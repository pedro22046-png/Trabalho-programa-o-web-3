<?php $titulo = 'Meus dados'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<div class="panel" style="max-width:520px;">
  <h2>Editar meus dados</h2>
  <form method="post" action="<?= base_url('painel/perfil') ?>">
    <div class="form-group">
      <label for="nome">Nome</label>
      <input type="text" id="nome" name="nome" value="<?= esc($usuario['nome']) ?>" required />
    </div>
    <div class="form-group">
      <label for="email">Email</label>
      <input type="email" id="email" name="email" value="<?= esc($usuario['email']) ?>" required />
    </div>
    <div class="form-group">
      <label for="senha">Nova senha (deixe em branco para manter)</label>
      <input type="password" id="senha" name="senha" placeholder="********" />
    </div>
    <button type="submit" class="btn btn-primary">Salvar</button>
  </form>
</div>

<?= $this->endSection() ?>
