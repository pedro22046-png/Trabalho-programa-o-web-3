<?php $titulo = 'Totens'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<div class="panel" style="max-width:520px;">
  <h2>Cadastrar totem</h2>
  <form method="post" action="<?= base_url('painel/totens/criar') ?>">
    <div class="form-group">
      <label for="nome">Nome do totem</label>
      <input type="text" id="nome" name="nome" placeholder="Ex.: Totem entrada" required />
    </div>
    <div class="form-group">
      <label for="codigo">Codigo (identificacao)</label>
      <input type="text" id="codigo" name="codigo" placeholder="Ex.: TOTEM-03" required />
    </div>
    <button type="submit" class="btn btn-primary">Cadastrar</button>
  </form>
</div>

<div class="panel">
  <h2>Totens cadastrados</h2>
  <?php if (empty($totens)): ?>
    <p style="color:var(--text-muted);">Nenhum totem cadastrado ainda.</p>
  <?php else: ?>
    <table class="data">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>Codigo</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($totens as $t): ?>
          <tr>
            <td>#<?= (int) $t['id'] ?></td>
            <td><strong><?= esc($t['nome']) ?></strong></td>
            <td><?= esc($t['codigo']) ?></td>
            <td>
              <a class="btn btn-sm btn-danger"
                 href="<?= base_url('painel/totens/excluir/' . $t['id']) ?>"
                 onclick="return confirm('Excluir este totem?')">Excluir</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<?= $this->endSection() ?>
