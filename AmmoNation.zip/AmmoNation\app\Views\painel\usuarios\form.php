<?php $titulo = $titulo ?? 'Usuario'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<?php
  $editando = $usuario !== null;
  $acao = $editando
      ? base_url('painel/usuarios/atualizar/' . $usuario['id'])
      : base_url('painel/usuarios/criar');
  $papelAtual = old('papel', $editando ? $usuario['papel'] : 'usuario');
?>

<div class="panel" style="max-width:520px;">
  <h2><?= esc($titulo) ?></h2>

  <form method="post" action="<?= $acao ?>">
    <div class="form-group">
      <label for="nome">Nome</label>
      <input type="text" id="nome" name="nome"
             value="<?= esc(old('nome', $editando ? $usuario['nome'] : '')) ?>" required />
    </div>
    <div class="form-group">
      <label for="email">Email</label>
      <input type="email" id="email" name="email"
             value="<?= esc(old('email', $editando ? $usuario['email'] : '')) ?>" required />
    </div>
    <div class="form-group">
      <label for="senha">
        Senha <?= $editando ? '(deixe em branco para manter)' : '' ?>
      </label>
      <input type="password" id="senha" name="senha" <?= $editando ? '' : 'required' ?> />
    </div>
    <div class="form-group">
      <label for="papel">Papel</label>
      <select id="papel" name="papel">
        <option value="usuario"     <?= $papelAtual === 'usuario' ? 'selected' : '' ?>>Usuario</option>
        <option value="super_admin" <?= $papelAtual === 'super_admin' ? 'selected' : '' ?>>Super Admin</option>
      </select>
    </div>

    <div class="btn-row">
      <button type="submit" class="btn btn-primary">Salvar</button>
      <a class="btn btn-secondary" href="<?= base_url('painel/usuarios') ?>">Cancelar</a>
    </div>
  </form>
</div>

<?= $this->endSection() ?>
