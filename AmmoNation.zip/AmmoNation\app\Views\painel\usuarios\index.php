<?php $titulo = 'Usuarios'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
    <h2 style="margin:0;">Controle de usuarios</h2>
    <a class="btn btn-primary" href="<?= base_url('painel/usuarios/novo') ?>">+ Novo usuario</a>
  </div>

  <table class="data">
    <thead>
      <tr>
        <th>Nome</th>
        <th>Email</th>
        <th>Papel</th>
        <th>Situacao</th>
        <th>Acoes</th>
      </tr>
    </thead>
    <tbody>
      <?php $meuId = (int) session()->get('usuario_id'); ?>
      <?php foreach ($usuarios as $u): ?>
        <?php
          $bloqueado = ($u['bloqueado'] === 't' || $u['bloqueado'] === true);
          $admin     = ($u['papel'] === 'super_admin');
        ?>
        <tr>
          <td>
            <strong><?= esc($u['nome']) ?></strong>
            <?php if ((int) $u['id'] === $meuId): ?>
              <span class="badge badge-user">voce</span>
            <?php endif; ?>
          </td>
          <td><?= esc($u['email']) ?></td>
          <td>
            <span class="badge <?= $admin ? 'badge-admin' : 'badge-user' ?>">
              <?= $admin ? 'Super Admin' : 'Usuario' ?>
            </span>
          </td>
          <td>
            <span class="badge <?= $bloqueado ? 'badge-nao' : 'badge-sim' ?>">
              <?= $bloqueado ? 'Bloqueado' : 'Ativo' ?>
            </span>
          </td>
          <td>
            <div class="btn-row">
              <a class="btn btn-sm btn-secondary" href="<?= base_url('painel/usuarios/editar/' . $u['id']) ?>">Editar</a>
              <?php if ((int) $u['id'] !== $meuId): ?>
                <?php if ($bloqueado): ?>
                  <a class="btn btn-sm btn-success" href="<?= base_url('painel/usuarios/desbloquear/' . $u['id']) ?>">Desbloquear</a>
                <?php else: ?>
                  <a class="btn btn-sm btn-danger" href="<?= base_url('painel/usuarios/bloquear/' . $u['id']) ?>">Bloquear</a>
                <?php endif; ?>
                <a class="btn btn-sm btn-danger"
                   href="<?= base_url('painel/usuarios/excluir/' . $u['id']) ?>"
                   onclick="return confirm('Excluir este usuario?')">Excluir</a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?= $this->endSection() ?>
