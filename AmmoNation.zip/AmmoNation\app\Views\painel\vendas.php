<?php $titulo = 'Painel de vendas'; ?>
<?= $this->extend('painel/layout') ?>

<?= $this->section('conteudo') ?>

<div class="panel">
  <div class="filter-bar">
    <label>
      Periodo do grafico:
      <select id="filtro-dias" onchange="window.location.href='<?= base_url('painel/vendas') ?>?dias='+this.value">
        <option value="7"  <?= $dias === 7  ? 'selected' : '' ?>>Ultimos 7 dias</option>
        <option value="15" <?= $dias === 15 ? 'selected' : '' ?>>Ultimos 15 dias</option>
        <option value="30" <?= $dias === 30 ? 'selected' : '' ?>>Ultimos 30 dias</option>
      </select>
    </label>
  </div>

  <h2>Grafico de vendas dos ultimos <?= (int) $dias ?> dias</h2>
  <canvas id="grafico-vendas" height="90"></canvas>
</div>

<div class="panel">
  <h2>Vendas por dia</h2>
  <?php if (empty($porDia)): ?>
    <p style="color:var(--text-muted);">Ainda nao ha vendas registradas.</p>
  <?php else: ?>
    <table class="data">
      <thead>
        <tr>
          <th>Data</th>
          <th>Valor total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($porDia as $linha): ?>
          <tr>
            <td><?= esc(date('d/m/Y', strtotime($linha['dia']))) ?></td>
            <td><strong>R$ <?= number_format((float) $linha['valor'], 2, ',', '.') ?></strong></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  const labels = <?= json_encode($labels) ?>;
  const valores = <?= json_encode($valores) ?>;

  new Chart(document.getElementById('grafico-vendas'), {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Vendas (R$)',
        data: valores,
        borderColor: '#5b3bff',
        backgroundColor: 'rgba(91, 59, 255, 0.12)',
        fill: true,
        tension: 0.3,
        pointBackgroundColor: '#5b3bff',
      }],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } },
    },
  });
</script>

<?= $this->endSection() ?>
