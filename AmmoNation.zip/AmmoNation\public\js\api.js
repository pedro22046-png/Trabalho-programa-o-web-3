const Api = {
  baseUrl: '',

  fallbackProducts: [
    {
      id: 1,
      nome: 'Desert Eagle',
      descricao: 'Pistola de alto calibre com mira precisa.',
      preco: 1520,
      categoria: 'Pistola',
      imagem: 'assets/imagens/desert-eagle.svg',
    },
    {
      id: 2,
      nome: 'AK-47',
      descricao: 'Rifle robusto para operações rápidas.',
      preco: 2400,
      categoria: 'Rifle',
      imagem: 'assets/imagens/ak47.svg',
    },
    {
      id: 3,
      nome: 'M4A1',
      descricao: 'Rifle leve com excelente controle.',
      preco: 2750,
      categoria: 'Rifle',
      imagem: 'assets/imagens/m4a1.svg',
    },
    {
      id: 4,
      nome: 'Glock 19',
      descricao: 'Pistola compacta para uso tático.',
      preco: 1280,
      categoria: 'Pistola',
      imagem: 'assets/imagens/glock19.svg',
    },
    {
      id: 5,
      nome: 'Coletes',
      descricao: 'Proteção leve para operações em campo.',
      preco: 720,
      categoria: 'Acessório',
      imagem: 'assets/imagens/coletes.svg',
    },
    {
      id: 6,
      nome: 'Munição 9mm',
      descricao: 'Cartuchos de uso geral para pistolas.',
      preco: 230,
      categoria: 'Acessório',
      imagem: 'assets/imagens/municao-9mm.svg',
    },
  ],

  async fetchProdutos() {
    try {
      const response = await fetch(`${this.baseUrl}/api/produtos`);
      if (!response.ok) {
        throw new Error(`Erro ao buscar produtos: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.warn('API não disponível, usando dados de exemplo local.', error);
      return this.fallbackProducts;
    }
  },

  async fetchTotens() {
    try {
      const response = await fetch(`${this.baseUrl}/api/totens`);
      if (!response.ok) {
        throw new Error(`Erro ao buscar totens: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.warn('Não foi possível buscar os totens.', error);
      return [];
    }
  },

  async criarPedido(itens, totemId = null) {
    const response = await fetch(`${this.baseUrl}/api/pedidos`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ itens, totem_id: totemId }),
    });

    if (!response.ok) {
      let msg = 'Erro ao enviar o pedido.';
      try {
        const data = await response.json();
        msg = data.erro || msg;
      } catch (e) {
        // resposta sem json
      }
      throw new Error(msg);
    }

    return await response.json();
  },
};

const Utils = {
  formatCurrency(value) {
    return Number(value).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  },

  showMessage(container, text, type = 'info') {
    if (!container) return;
    container.textContent = text;
    container.style.display = 'block';
    container.style.borderColor = type === 'error' ? 'rgba(255, 94, 94, 0.3)' : 'rgba(91, 59, 255, 0.24)';
    container.style.color = type === 'error' ? '#8b1a1a' : 'var(--text)';
  },

  hideMessage(container) {
    if (!container) return;
    container.textContent = '';
    container.style.display = 'none';
  },
};
