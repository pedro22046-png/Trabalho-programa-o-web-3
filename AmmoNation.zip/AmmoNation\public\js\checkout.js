const CART_KEY = 'pedido-cart';
const TOTEM_ID_KEY = 'totem-id';

const orderSummary = document.getElementById('order-summary');
const checkoutTotal = document.getElementById('checkout-total');
const finishBtn = document.getElementById('finish-btn');
const checkoutNote = document.getElementById('checkout-note');

window.addEventListener('DOMContentLoaded', initCheckout);
finishBtn.addEventListener('click', finalizarPedido);

function getCart() {
  return JSON.parse(localStorage.getItem(CART_KEY) || '[]');
}

function initCheckout() {
  const cart = getCart();
  if (!cart.length) {
    window.location.href = 'produtos.html';
    return;
  }

  orderSummary.innerHTML = cart
    .map(
      (item) => `
      <div class="order-row">
        <div class="order-definition">
          <strong>${item.quantidade}x ${item.nome}</strong>
          <span>Unitário: ${Utils.formatCurrency(item.preco)}</span>
        </div>
        <strong>${Utils.formatCurrency(item.preco * item.quantidade)}</strong>
      </div>`
    )
    .join('');

  const total = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  checkoutTotal.textContent = Utils.formatCurrency(total);
}

async function finalizarPedido() {
  const cart = getCart();
  if (!cart.length) {
    window.location.href = 'produtos.html';
    return;
  }

  const originalText = finishBtn.textContent;
  finishBtn.disabled = true;
  finishBtn.textContent = 'Enviando...';
  checkoutNote.style.color = '';
  checkoutNote.textContent = 'Enviando seu pedido para a cozinha...';

  const totemId = localStorage.getItem(TOTEM_ID_KEY) || null;

  try {
    const pedido = await Api.criarPedido(cart, totemId);
    // Guarda o pedido final (com o numero gerado pelo backend) e limpa o carrinho
    localStorage.setItem('pedido-final', JSON.stringify(pedido));
    localStorage.removeItem(CART_KEY);
    window.location.href = 'pedido.html';
  } catch (error) {
    finishBtn.disabled = false;
    finishBtn.textContent = originalText;
    checkoutNote.style.color = '#8b1a1a';
    checkoutNote.textContent =
      error.message || 'Não foi possível enviar o pedido. Verifique a conexão e tente novamente.';
  }
}
