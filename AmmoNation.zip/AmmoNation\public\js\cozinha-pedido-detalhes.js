const loadingDiv = document.getElementById('loading');
const contentDiv = document.getElementById('content');
const errorDiv = document.getElementById('error');
const successDiv = document.getElementById('success');

const orderNumberEl = document.getElementById('order-number');
const orderDateEl = document.getElementById('order-date');
const orderStatusEl = document.getElementById('order-status');
const orderTotalEl = document.getElementById('order-total');
const itemsListEl = document.getElementById('items-list');

const btnPreparando = document.getElementById('btn-preparando');
const btnPronto = document.getElementById('btn-pronto');
const btnCancelar = document.getElementById('btn-cancelar');

let pedidoAtual = null;

window.addEventListener('DOMContentLoaded', carregarDetalhes);

btnPreparando.addEventListener('click', () => atualizarStatus('preparando'));
btnPronto.addEventListener('click', () => atualizarStatus('pronto'));
btnCancelar.addEventListener('click', () => {
  if (
    confirm(
      'Tem certeza que deseja cancelar este pedido? Esta ação não pode ser desfeita.'
    )
  ) {
    atualizarStatus('cancelado');
  }
});

async function carregarDetalhes() {
  try {
    loadingDiv.style.display = 'block';

    const params = new URLSearchParams(window.location.search);
    const pedidoId = params.get('id');

    if (!pedidoId) {
      mostrarErro('ID do pedido não fornecido');
      return;
    }

    const response = await fetch(`/api/cozinha/pedidos/${pedidoId}`);

    if (response.status === 404) {
      mostrarErro('Pedido não encontrado');
      return;
    }

    if (!response.ok) {
      throw new Error('Erro ao carregar pedido');
    }

    pedidoAtual = await response.json();
    renderizarDetalhes();
    loadingDiv.style.display = 'none';
    contentDiv.style.display = 'block';
  } catch (error) {
    console.error('Erro:', error);
    mostrarErro('Erro ao carregar os detalhes do pedido');
  }
}

function renderizarDetalhes() {
  // Informações básicas
  orderNumberEl.textContent = `#${pedidoAtual.numero}`;

  const dataFormatada = new Date(pedidoAtual.data).toLocaleString('pt-BR');
  orderDateEl.textContent = dataFormatada;

  const statusLabel = {
    recebido: 'Recebido',
    preparando: 'Preparando',
    pronto: 'Pronto',
    cancelado: 'Cancelado',
  }[pedidoAtual.status] || pedidoAtual.status;

  orderStatusEl.innerHTML = `
    <span class="order-status-badge status-${pedidoAtual.status}">
      ${statusLabel}
    </span>
  `;

  // Total
  orderTotalEl.textContent = Utils.formatCurrency(pedidoAtual.total);

  // Itens
  const itensHtml = pedidoAtual.itens
    .map(
      (item) => `
      <div class="item-row">
        <div class="item-details">
          <div class="item-name">${item.nome}</div>
          <div class="item-quantity">Quantidade: ${item.quantidade}</div>
        </div>
        <div class="item-price">
          ${Utils.formatCurrency(item.preco * item.quantidade)}
        </div>
      </div>`
    )
    .join('');

  itemsListEl.innerHTML = itensHtml;

  // Mostrar/esconder botões dependendo do status
  btnPreparando.style.display =
    pedidoAtual.status === 'recebido' ? 'block' : 'none';
  btnPronto.style.display =
    pedidoAtual.status === 'preparando' ? 'block' : 'none';
  btnCancelar.style.display =
    pedidoAtual.status !== 'pronto' && pedidoAtual.status !== 'cancelado'
      ? 'block'
      : 'none';
}

async function atualizarStatus(novoStatus) {
  try {
    btnPreparando.disabled = true;
    btnPronto.disabled = true;
    btnCancelar.disabled = true;

    const response = await fetch(
      `/api/cozinha/pedidos/${pedidoAtual.id}/status`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: novoStatus }),
      }
    );

    if (!response.ok) {
      throw new Error('Erro ao atualizar status');
    }

    pedidoAtual = await response.json();

    const mensagens = {
      preparando: '👨‍🍳 Pedido marcado como "Preparando"',
      pronto: '✅ Pedido pronto para retirada!',
      cancelado: '❌ Pedido cancelado',
    };

    mostrarSucesso(mensagens[novoStatus] || 'Status atualizado');
    renderizarDetalhes();

    setTimeout(() => {
      successDiv.style.display = 'none';
    }, 3000);
  } catch (error) {
    console.error('Erro:', error);
    mostrarErro('Erro ao atualizar o status do pedido');
  } finally {
    btnPreparando.disabled = false;
    btnPronto.disabled = false;
    btnCancelar.disabled = false;
  }
}

function mostrarErro(mensagem) {
  loadingDiv.style.display = 'none';
  errorDiv.textContent = mensagem;
  errorDiv.style.display = 'block';
}

function mostrarSucesso(mensagem) {
  successDiv.textContent = mensagem;
  successDiv.style.display = 'block';
}
