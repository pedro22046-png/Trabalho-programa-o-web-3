const ordersContainer = document.getElementById('orders-container');
const loadingDiv = document.getElementById('loading');
const emptyStateDiv = document.getElementById('empty-state');
const refreshBtn = document.getElementById('refresh-btn');

window.addEventListener('DOMContentLoaded', () => {
  carregarPedidos();
  // Atualizar a cada 10 segundos
  setInterval(carregarPedidos, 10000);
});

refreshBtn.addEventListener('click', carregarPedidos);

async function carregarPedidos() {
  try {
    loadingDiv.style.display = 'block';
    ordersContainer.innerHTML = '';

    const response = await fetch('/api/cozinha/pedidos');
    
    if (!response.ok) {
      throw new Error('Erro ao carregar pedidos');
    }

    const pedidos = await response.json();
    loadingDiv.style.display = 'none';

    if (pedidos.length === 0) {
      emptyStateDiv.style.display = 'block';
      return;
    }

    emptyStateDiv.style.display = 'none';

    pedidos.forEach((pedido) => {
      const card = criarCartaoPedido(pedido);
      ordersContainer.appendChild(card);
    });
  } catch (error) {
    console.error('Erro:', error);
    loadingDiv.innerHTML = '<p style="color: red;">Erro ao carregar pedidos</p>';
  }
}

function criarCartaoPedido(pedido) {
  const card = document.createElement('div');
  card.className = `order-card ${pedido.status}`;
  
  const dataFormatada = new Date(pedido.data).toLocaleString('pt-BR');
  
  const itensHtml = pedido.itens
    .map(
      (item) => `
      <div class="order-item">
        <span>${item.quantidade}x ${item.nome}</span>
        <span>${Utils.formatCurrency(item.preco)}</span>
      </div>`
    )
    .join('');

  const statusLabel = {
    recebido: 'Recebido',
    preparando: 'Preparando',
    pronto: 'Pronto',
    cancelado: 'Cancelado',
  }[pedido.status] || pedido.status;

  card.innerHTML = `
    <div class="order-header">
      <div class="order-number">Pedido #${pedido.numero}</div>
      <span class="order-status status-${pedido.status}">
        <span class="status-badge badge-${pedido.status}"></span>
        ${statusLabel}
      </span>
    </div>
    <div class="order-date">${dataFormatada}</div>
    <div class="order-items">
      ${itensHtml}
    </div>
    <div class="order-total">
      Total: ${Utils.formatCurrency(pedido.total)}
    </div>
  `;

  card.addEventListener('click', () => {
    window.location.href = `cozinha-pedido-detalhes.html?id=${pedido.id}`;
  });

  return card;
}
