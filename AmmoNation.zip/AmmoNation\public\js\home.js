// Tela inicial: identifica de qual totem o pedido esta saindo (Parte 4).
const TOTEM_ID_KEY = 'totem-id';
const TOTEM_NOME_KEY = 'totem-nome';

const totemSelect = document.getElementById('totem');
const startBtn = document.getElementById('start-btn');
const homeMsg = document.getElementById('home-msg');

window.addEventListener('DOMContentLoaded', initHome);

async function initHome() {
  const totens = await Api.fetchTotens();

  if (!totens.length) {
    totemSelect.innerHTML = '<option value="">Nenhum totem cadastrado</option>';
    return;
  }

  const salvo = localStorage.getItem(TOTEM_ID_KEY);

  totemSelect.innerHTML =
    '<option value="">Selecione o totem...</option>' +
    totens
      .map(
        (t) =>
          `<option value="${t.id}" ${String(t.id) === salvo ? 'selected' : ''}>${t.nome}</option>`
      )
      .join('');

  totemSelect.addEventListener('change', () => {
    const id = totemSelect.value;
    const nome = totemSelect.options[totemSelect.selectedIndex].text;
    if (id) {
      localStorage.setItem(TOTEM_ID_KEY, id);
      localStorage.setItem(TOTEM_NOME_KEY, nome);
      homeMsg.textContent = '';
    }
  });
}

startBtn.addEventListener('click', (event) => {
  if (!totemSelect.value) {
    event.preventDefault();
    homeMsg.textContent = 'Escolha qual totem você está usando antes de iniciar.';
    homeMsg.style.color = '#8b1a1a';
  }
});
