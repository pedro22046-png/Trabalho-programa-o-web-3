const RECEIPT_KEY = 'pedido-final';
const receiptCard = document.getElementById('receipt-card');
const novoPedidoBtn = document.getElementById('novo-pedido-btn');

window.addEventListener('DOMContentLoaded', renderReceipt);
novoPedidoBtn.addEventListener('click', handleNovoPedido);

function renderReceipt() {
  const order = JSON.parse(localStorage.getItem(RECEIPT_KEY) || 'null');
  if (!order) {
    window.location.href = 'index.html';
    return;
  }

  const itemsHtml = order.itens
    .map(
      (item) => `
      <div class="receipt-item">
        <span>${item.quantidade}x ${item.nome}</span>
        <span>${Utils.formatCurrency(item.preco * item.quantidade)}</span>
      </div>`
    )
    .join('');

  receiptCard.innerHTML = `
    <div class="order-number-big">Nº ${order.numero}</div>
    ${itemsHtml}
    <div class="receipt-total">
      <span>Total</span>
      <strong>${Utils.formatCurrency(order.total)}</strong>
    </div>`;
}

function handleNovoPedido() {
  localStorage.removeItem(RECEIPT_KEY);
  window.location.href = 'index.html';
}
