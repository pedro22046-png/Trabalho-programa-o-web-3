const CART_KEY = 'pedido-cart';
let produtos = [];
let activeFilter = 'Todos';

const productGrid = document.getElementById('product-grid');
const messageBox = document.getElementById('message-box');
const filterButtons = document.querySelectorAll('.filter-btn');
const cartTotal = document.getElementById('cart-total');

window.addEventListener('DOMContentLoaded', initProdutos);

async function initProdutos() {
  Utils.showMessage(messageBox, 'Carregando produtos...', 'info');

  try {
    produtos = await Api.fetchProdutos();
    Utils.hideMessage(messageBox);
    renderFilters();
    renderProducts();
    renderCartTotal();
  } catch (error) {
    Utils.showMessage(messageBox, error.message, 'error');
  }
}

function getCart() {
  return JSON.parse(localStorage.getItem(CART_KEY) || '[]');
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function renderFilters() {
  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      filterButtons.forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');
      activeFilter = button.dataset.filter;
      renderProducts();
    });
  });
}

function renderProducts() {
  const filtered = produtos.filter((produto) => {
    if (activeFilter === 'Todos') {
      return true;
    }
    return produto.categoria === activeFilter;
  });

  if (!filtered.length) {
    productGrid.innerHTML = '<p>Nenhum produto encontrado para essa categoria.</p>';
    return;
  }

  productGrid.innerHTML = filtered
    .map((produto) => {
      const image = produto.imagem || 'https://via.placeholder.com/360x240?text=Arma';
      return `
        <article class="product-card" data-id="${produto.id}">
          <div class="product-image">
            <img src="${image}" alt="Imagem de ${produto.nome}" />
          </div>
          <div>
            <h3 class="product-title">${produto.nome}</h3>
            <p class="product-description">${produto.descricao}</p>
          </div>
          <div class="product-footer">
            <span class="product-price">${Utils.formatCurrency(produto.preco)}</span>
            <button class="btn btn-primary" data-action="add" data-id="${produto.id}">Adicionar</button>
          </div>
        </article>
      `;
    })
    .join('');
}

productGrid.addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;

  const action = button.dataset.action;
  const productId = Number(button.dataset.id);
  const produto = produtos.find((item) => item.id === productId);

  if (!produto) return;

  if (action === 'add') {
    addToCart(produto);
  }
});

function addToCart(produto) {
  const cart = getCart();
  const existing = cart.find((item) => item.id === produto.id);

  if (existing) {
    existing.quantidade += 1;
  } else {
    cart.push({
      id: produto.id,
      nome: produto.nome,
      descricao: produto.descricao,
      preco: produto.preco,
      imagem: produto.imagem,
      quantidade: 1,
    });
  }

  saveCart(cart);
  renderCartTotal();
  Utils.showMessage(messageBox, `${produto.nome} foi adicionado ao carrinho.`);
}

function renderCartTotal() {
  const cart = getCart();
  const total = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  cartTotal.textContent = Utils.formatCurrency(total);
}
