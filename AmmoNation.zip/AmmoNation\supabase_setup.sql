-- ============================================================
-- Ammo Nation — Banco de dados (Supabase / PostgreSQL)
--
-- COMO USAR:
--   1. Abra o painel do Supabase do seu projeto
--   2. Menu lateral -> "SQL Editor" -> "New query"
--   3. Cole TODO este arquivo e clique em "Run"
--
-- Pode rodar quantas vezes quiser: e seguro repetir (idempotente).
-- Obs.: o super admin e os produtos sao criados pelo backend
--       (php spark setup) porque a senha precisa ser criptografada.
-- ============================================================

-- 1) PRODUTOS (as armas do catalogo)
create table if not exists public.produtos (
  id          bigint generated always as identity primary key,
  nome        text not null,
  descricao   text,
  preco       numeric(10,2) not null default 0,
  categoria   text,
  imagem      text,
  disponivel  boolean not null default true,
  estoque     integer not null default 1000,
  created_at  timestamptz not null default now()
);

-- 2) TOTENS (Parte 4 - cada totem tem uma identificacao)
create table if not exists public.totens (
  id          bigint generated always as identity primary key,
  nome        text not null,
  codigo      text unique not null,
  created_at  timestamptz not null default now()
);

-- 3) PEDIDOS
create table if not exists public.pedidos (
  id          bigint generated always as identity primary key,
  numero      text,
  totem_id    bigint references public.totens(id) on delete set null,
  status      text not null default 'recebido'
              check (status in ('recebido','preparando','pronto','cancelado')),
  total       numeric(10,2) not null default 0,
  created_at  timestamptz not null default now()
);

-- 4) ITENS DO PEDIDO
create table if not exists public.itens_pedido (
  id          bigint generated always as identity primary key,
  pedido_id   bigint not null references public.pedidos(id) on delete cascade,
  produto_id  bigint references public.produtos(id) on delete set null,
  nome        text not null,
  preco       numeric(10,2) not null default 0,
  quantidade  integer not null default 1
);

-- 5) USUARIOS (Parte 3 - controle de usuarios do backend)
create table if not exists public.usuarios (
  id          bigint generated always as identity primary key,
  nome        text not null,
  email       text unique not null,
  senha_hash  text not null,
  papel       text not null default 'usuario'
              check (papel in ('super_admin','usuario')),
  bloqueado   boolean not null default false,
  created_at  timestamptz not null default now()
);

-- 6) Seguranca: liga o RLS para trancar o acesso pela chave "anon".
--    O backend conecta como usuario "postgres", que ignora o RLS,
--    entao continua funcionando normalmente.
alter table public.produtos     enable row level security;
alter table public.totens       enable row level security;
alter table public.pedidos      enable row level security;
alter table public.itens_pedido enable row level security;
alter table public.usuarios     enable row level security;

-- Pronto! Tabelas criadas. Agora rode no backend:  php spark setup
