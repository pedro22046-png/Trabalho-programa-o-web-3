import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { View, StyleSheet } from 'react-native';
import { AuthProvider } from './src/contexts/AuthContext';
import RootNavigator from './src/navigation/RootNavigator';
import {
  configurarNotificacoes,
  pedirPermissaoNotificacoes,
} from './src/services/notificationService';

export default function App() {
  useEffect(() => {
    // Configura o handler de notificações (uma vez) e pede permissão.
    // Não trava o app caso o usuário negue.
    configurarNotificacoes();
    pedirPermissaoNotificacoes();
  }, []);

  return (
    <AuthProvider>
      <View style={styles.container}>
        <RootNavigator />
        <StatusBar style="auto" />
      </View>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
