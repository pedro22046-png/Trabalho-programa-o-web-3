# Como rodar o RotinaApp 🚀

Guia passo a passo (feito para iniciante). Você vai rodar o app no seu **celular** usando o aplicativo **Expo Go**.

---

## 1. Instalar o Node.js (só na primeira vez)

O projeto não sobe sem o Node.js instalado no computador.

1. Baixe a versão **LTS** em: https://nodejs.org
2. Instale (Avançar → Avançar → Concluir).
3. Feche e abra o terminal de novo e confira:
   ```bash
   node -v
   npm -v
   ```
   Se aparecerem números de versão, está tudo certo.

> ⚠️ Hoje o `node_modules` da pasta está **incompleto** (faltam pacotes como
> `react-native-maps`, `expo-location`, `babel-preset-expo`). Por isso o passo 2
> (`npm install`) é **obrigatório**.

## 2. Instalar as dependências do projeto

Abra o terminal **dentro da pasta do projeto** e rode:

```bash
npm install
```

Isso instala tudo que está no `package.json` (já corrigi as versões certas para o Expo SDK 54).

> 💡 Se em algum momento o Expo avisar que uma dependência está em versão errada,
> rode este comando que ele alinha tudo sozinho ao SDK:
> ```bash
> npx expo install --fix
> ```

## 3. Preparar o banco de dados (Supabase)

1. Entre no painel do seu projeto Supabase.
2. Menu lateral → **SQL Editor** → **New query**.
3. Abra o arquivo [`supabase_setup.sql`](supabase_setup.sql), copie tudo, cole e clique em **Run**.
   - Isso cria a tabela `tarefas` e liga a segurança (RLS) para cada usuário ver só as próprias tarefas.
4. **Importante para o login funcionar de primeira:** em
   **Authentication → Sign In / Providers → Email**, desative a opção
   **"Confirm email"** (assim você entra logo após cadastrar, sem precisar
   confirmar por e-mail). Para um trabalho de apresentação isso facilita muito.

> A conexão com o Supabase já está configurada em `src/services/supabase.ts`.

## 4. Rodar o app

No terminal, dentro da pasta:

```bash
npx expo start
```

Vai aparecer um **QR code**.

1. Instale o app **Expo Go** no celular (Play Store / App Store).
2. Conecte o **celular e o computador no mesmo Wi-Fi**.
3. Abra o Expo Go e escaneie o QR code.
   - Não conectou? Rode `npx expo start --tunnel` (funciona mesmo em redes diferentes).

---

## Como testar cada parte

- **Login/Cadastro:** crie uma conta, saia (botão "Sair") e entre de novo.
- **Tarefas:** toque no botão azul **+** para criar; use **Editar / Excluir / Concluir** no card.
- **Filtros:** use os botões de prioridade (Alta/Média/Baixa) e status (Todos/Pendentes/Concluídas).
- **Mapa:** ao criar a tarefa, arraste o pino para escolher o local. Na tela inicial
  os pinos aparecem **coloridos pela prioridade**. Toque num pino → "callout" → abre os detalhes.
- **Notificação de proximidade (Semana 4):**
  1. Crie uma tarefa **no seu local atual** (o mapa já centraliza em você).
  2. Na tela inicial, no card **"Alerta de proximidade"**, deixe o raio grande (ex.: `500`).
  3. Deixe o app aberto: como você já está dentro do raio, a notificação chega em alguns segundos.
  4. Para um teste "de verdade", saia da área e volte andando até o local.

> As **notificações locais funcionam no Expo Go**. O que não funciona no Expo Go é
> alerta em **segundo plano** (app fechado) — por isso a verificação roda com o app aberto.
> Use um **celular físico** (no emulador a localização é simulada).

---

## Resumo rápido (quando já estiver tudo instalado)

```bash
npm install        # só se faltar algo
npx expo start     # abre o QR code
```
