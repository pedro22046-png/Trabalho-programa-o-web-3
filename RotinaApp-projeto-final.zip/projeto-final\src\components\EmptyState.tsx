import { View, Text, StyleSheet } from 'react-native';

function EmptyState({ message = 'Nenhuma tarefa encontrada.' }: { message?: string }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  text: { color: '#666', fontSize: 16 },
});

export default EmptyState;
