import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import type { ReactNode } from 'react';
import { Priority } from '../types/Task';

type Props = {
  priorityFilter: Priority | 'todas';
  setPriorityFilter: (p: Priority | 'todas') => void;
  statusFilter: 'todos' | 'pendentes' | 'concluidas';
  setStatusFilter: (s: 'todos' | 'pendentes' | 'concluidas') => void;
};

function FilterBar({ priorityFilter, setPriorityFilter, statusFilter, setStatusFilter }: Props) {
  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <FilterButton active={priorityFilter === 'todas'} onPress={() => setPriorityFilter('todas')}>
          Todas
        </FilterButton>
        <FilterButton active={priorityFilter === 'alta'} onPress={() => setPriorityFilter('alta')}>
          Alta
        </FilterButton>
        <FilterButton active={priorityFilter === 'media'} onPress={() => setPriorityFilter('media')}>
          Média
        </FilterButton>
        <FilterButton active={priorityFilter === 'baixa'} onPress={() => setPriorityFilter('baixa')}>
          Baixa
        </FilterButton>
      </View>

      <View style={[styles.row, { marginTop: 8 }]}> 
        <FilterButton active={statusFilter === 'todos'} onPress={() => setStatusFilter('todos')}>
          Todos
        </FilterButton>
        <FilterButton active={statusFilter === 'pendentes'} onPress={() => setStatusFilter('pendentes')}>
          Pendentes
        </FilterButton>
        <FilterButton active={statusFilter === 'concluidas'} onPress={() => setStatusFilter('concluidas')}>
          Concluídas
        </FilterButton>
      </View>
    </View>
  );
}

function FilterButton({ active, onPress, children }: { active?: boolean; onPress: () => void; children: ReactNode }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.filterBtn, active ? styles.active : null]}>
      <Text style={[styles.filterText, active ? styles.activeText : null]}>{children}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { padding: 12, backgroundColor: '#fff' },
  row: { flexDirection: 'row', justifyContent: 'space-around' },
  filterBtn: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  active: { backgroundColor: '#2563eb' },
  filterText: { color: '#333' },
  activeText: { color: '#fff', fontWeight: '700' },
});

export default FilterBar;
