import { View, Text, StyleSheet } from 'react-native';
import { Priority } from '../types/Task';
import { getCorPrioridade, getRotuloPrioridade } from '../utils/priorities';

function PriorityBadge({ prioridade }: { prioridade: Priority }) {
  return (
    <View style={[styles.container, { backgroundColor: getCorPrioridade(prioridade) }]}>
      <Text style={styles.text}>{getRotuloPrioridade(prioridade).toUpperCase()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  text: { color: '#fff', fontWeight: '700', fontSize: 12 },
});

export default PriorityBadge;
