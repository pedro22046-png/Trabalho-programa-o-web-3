import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Task } from '../types/Task';
import PriorityBadge from './PriorityBadge';

type Props = {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onToggle: (id: string, completed: boolean) => void;
};

function TaskCard({ task, onEdit, onDelete, onToggle }: Props) {
  return (
    <View style={[styles.card, task.concluida ? styles.completedCard : null]}>
      <View style={styles.row}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, task.concluida ? styles.strike : null]}>{task.titulo}</Text>
          {task.descricao ? <Text style={styles.desc}>{task.descricao}</Text> : null}
        </View>

        <PriorityBadge prioridade={task.prioridade} />
      </View>

      <View style={styles.rowActions}>
        <Text style={styles.date}>{new Date(task.created_at).toLocaleString()}</Text>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onEdit(task)}>
            <Text style={styles.actionText}>Editar</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionBtn} onPress={() => onDelete(task.id)}>
            <Text style={[styles.actionText, { color: '#ef4444' }]}>Excluir</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionBtn} onPress={() => onToggle(task.id, !task.concluida)}>
            <Text style={[styles.actionText, { color: '#10b981' }]}>
              {task.concluida ? 'Reabrir' : 'Concluir'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 10,
    marginVertical: 8,
    marginHorizontal: 12,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  completedCard: { opacity: 0.7 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 16, fontWeight: '700' },
  desc: { color: '#666', marginTop: 4 },
  strike: { textDecorationLine: 'line-through', color: '#999' },
  rowActions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  date: { color: '#999', fontSize: 12 },
  actions: { flexDirection: 'row' },
  actionBtn: { marginLeft: 10 },
  actionText: { color: '#2563eb', fontWeight: '600' },
});

export default TaskCard;
