import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import supabase from '../services/supabase';

// Types
type User = {
  id: string;
  email?: string | null;
  [key: string]: any;
} | null;

type AuthContextData = {
  user: User;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error?: any } | null>;
  signUp: (name: string, email: string, password: string) => Promise<{ error?: any } | null>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextData | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Key for AsyncStorage
  const STORAGE_KEY = '@rotinaapp_session';

  // Restore session from Supabase or AsyncStorage
  useEffect(() => {
    let isMounted = true;

    const init = async () => {
      try {
        // Try to get session from Supabase first
        const { data } = await supabase.auth.getSession();
        const session = data.session;

        if (session && session.user && isMounted) {
          setUser(session.user as User);
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(session));
        } else {
          // Try to restore from AsyncStorage for React Native
          const stored = await AsyncStorage.getItem(STORAGE_KEY);
          if (stored) {
            const parsed = JSON.parse(stored);
            if (parsed?.user && isMounted) setUser(parsed.user as User);
          }
        }
      } catch (err) {
        // ignore for now
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    init();

    // Subscribe to auth state changes
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        setUser(session.user as User);
        AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(session)).catch(() => {});
      } else {
        setUser(null);
        AsyncStorage.removeItem(STORAGE_KEY).catch(() => {});
      }
    });

    return () => {
      isMounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  // Sign in function
  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        console.error('Supabase signIn error:', error);
        return { error };
      }
      if (data.session?.user) {
        setUser(data.session.user as User);
        await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data.session));
      } else {
        console.warn('Supabase signIn did not return a session:', data);
      }
      return null;
    } catch (err) {
      console.error('Supabase signIn exception:', err);
      return { error: err };
    }
  };

  // Sign up function
  const signUp = async (name: string, email: string, password: string) => {
    try {
      // supabase-js v2 expects a single object arg; include options under `options`.
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: name } } });
      if (error) return { error };
      // In Supabase flow, user may need to confirm email — we just inform the caller
      return null;
    } catch (err) {
      return { error: err };
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      // ignore
    } finally {
      setUser(null);
      await AsyncStorage.removeItem(STORAGE_KEY).catch(() => {});
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook for easier access
export const useAuth = (): AuthContextData => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

export default AuthContext;
