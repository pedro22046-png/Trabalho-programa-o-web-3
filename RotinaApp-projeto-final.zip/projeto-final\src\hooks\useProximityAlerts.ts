import { useEffect, useRef } from 'react';
import * as Location from 'expo-location';
import { Task } from '../types/Task';
import { distanciaEmMetros } from '../utils/distance';
import { notificarProximidade } from '../services/notificationService';

// Verifica a proximidade ENQUANTO O APP ESTÁ ABERTO (funciona no Expo Go).
// Acompanha a posição do usuário e, ao entrar no raio de uma tarefa pendente
// com localização, dispara uma notificação local. Guarda quais tarefas já
// foram avisadas para não notificar repetidamente no mesmo lugar.
export function useProximityAlerts(tasks: Task[], raioMetros: number, ativo: boolean = true) {
  const jaNotificadas = useRef<Set<string>>(new Set());
  const tasksRef = useRef<Task[]>(tasks);
  const raioRef = useRef<number>(raioMetros);

  // Mantém os valores mais recentes sem precisar reiniciar o monitoramento.
  useEffect(() => {
    tasksRef.current = tasks;
  }, [tasks]);

  useEffect(() => {
    raioRef.current = raioMetros;
  }, [raioMetros]);

  useEffect(() => {
    if (!ativo) return;

    let subscription: Location.LocationSubscription | null = null;
    let cancelado = false;

    const iniciar = async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted' || cancelado) return;

      subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Balanced,
          timeInterval: 10000, // no máximo a cada 10s (Android)
          distanceInterval: 20, // ou a cada 20 metros percorridos
        },
        (posicao) => {
          const { latitude, longitude } = posicao.coords;
          const raio = raioRef.current;

          tasksRef.current.forEach((tarefa) => {
            if (tarefa.concluida) return;
            if (tarefa.latitude == null || tarefa.longitude == null) return;

            const dist = distanciaEmMetros(latitude, longitude, tarefa.latitude, tarefa.longitude);

            if (dist <= raio) {
              // Entrou no raio: notifica uma vez.
              if (!jaNotificadas.current.has(tarefa.id)) {
                jaNotificadas.current.add(tarefa.id);
                notificarProximidade(tarefa.titulo, tarefa.nome_local);
              }
            } else if (dist > raio * 1.5) {
              // Saiu bem para fora do raio: libera para avisar de novo se voltar.
              jaNotificadas.current.delete(tarefa.id);
            }
          });
        },
      );
    };

    iniciar();

    return () => {
      cancelado = true;
      if (subscription) subscription.remove();
    };
  }, [ativo]);
}

export default useProximityAlerts;
