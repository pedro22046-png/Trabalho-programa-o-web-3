import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert } from 'react-native';
import { Task, Priority } from '../types/Task';
import * as taskService from '../services/taskService';

type StatusFilter = 'todos' | 'pendentes' | 'concluidas';

// Deixa a comparação de prioridade robusta: 'Média', 'média' e 'MEDIA'
// viram todos 'media'. Assim o filtro funciona mesmo com dados "sujos".
const normalizarPrioridade = (valor: string) =>
  (valor ?? '')
    .toLowerCase()
    .replace(/[áàâã]/g, 'a')
    .replace(/[éèê]/g, 'e')
    .replace(/[íì]/g, 'i')
    .replace(/[óòôõ]/g, 'o')
    .replace(/[úù]/g, 'u')
    .trim();

export const useTasks = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  // Filters
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'todas'>('todas');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('todos');

  const loadTasks = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await taskService.getTasks();
      if (error) {
        Alert.alert('Erro ao carregar tarefas', error.message || String(error));
        setTasks([]);
      } else {
        setTasks(data ?? []);
      }
    } catch (err: any) {
      Alert.alert('Erro ao carregar tarefas', err.message || String(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    await loadTasks();
    setRefreshing(false);
  }, [loadTasks]);

  const createTask = useCallback(async (payload: any) => {
    try {
      const { data, error } = await taskService.createTask(payload);
      if (error) {
        Alert.alert('Erro ao criar tarefa', error.message || String(error));
        return null;
      }
      setTasks(prev => [data!, ...prev]);
      return data;
    } catch (err: any) {
      Alert.alert('Erro ao criar tarefa', err.message || String(err));
      return null;
    }
  }, []);

  const updateTask = useCallback(async (id: string, payload: Partial<Task>) => {
    try {
      const { data, error } = await taskService.updateTask(id, payload);
      if (error) {
        Alert.alert('Erro ao atualizar tarefa', error.message || String(error));
        return null;
      }
      setTasks(prev => prev.map(t => (t.id === id ? (data as Task) : t)));
      return data;
    } catch (err: any) {
      Alert.alert('Erro ao atualizar tarefa', err.message || String(err));
      return null;
    }
  }, []);

  const deleteTask = useCallback(async (id: string) => {
    try {
      const { error } = await taskService.deleteTask(id);
      if (error) {
        Alert.alert('Erro ao excluir tarefa', error.message || String(error));
        return false;
      }
      setTasks(prev => prev.filter(t => t.id !== id));
      return true;
    } catch (err: any) {
      Alert.alert('Erro ao excluir tarefa', err.message || String(err));
      return false;
    }
  }, []);

  const toggleTaskCompleted = useCallback(async (id: string, completed: boolean) => {
    try {
      const { data, error } = await taskService.toggleTaskCompleted(id, completed);
      if (error) {
        Alert.alert('Erro ao atualizar tarefa', error.message || String(error));
        return null;
      }
      setTasks(prev => prev.map(t => (t.id === id ? (data as Task) : t)));
      return data;
    } catch (err: any) {
      Alert.alert('Erro ao atualizar tarefa', err.message || String(err));
      return null;
    }
  }, []);

  const filteredTasks = useMemo(() => {
    return tasks.filter(t => {
      if (priorityFilter !== 'todas' && normalizarPrioridade(t.prioridade) !== priorityFilter) return false;
      if (statusFilter === 'pendentes' && t.concluida) return false;
      if (statusFilter === 'concluidas' && !t.concluida) return false;
      return true;
    });
  }, [tasks, priorityFilter, statusFilter]);

  return {
    tasks,
    loading,
    refreshing,
    loadTasks,
    refresh,
    createTask,
    updateTask,
    deleteTask,
    toggleTaskCompleted,
    priorityFilter,
    setPriorityFilter,
    statusFilter,
    setStatusFilter,
    filteredTasks,
  };
};

export default useTasks;
