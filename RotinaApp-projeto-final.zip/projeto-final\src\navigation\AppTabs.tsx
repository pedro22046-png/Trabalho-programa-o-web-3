import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from '../screens/HomeScreen';
import TaskFormScreen from '../screens/TaskFormScreen';
import TaskDetailsScreen from '../screens/TaskDetailsScreen';

export type AppTabsParamList = {
  Home: undefined;
  TaskForm: { task?: any } | undefined;
  TaskDetails: { task: any } | undefined;
};

const Stack = createNativeStackNavigator<AppTabsParamList>();

function AppTabs() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="TaskForm" component={TaskFormScreen} options={{ title: 'Tarefa' }} />
      <Stack.Screen name="TaskDetails" component={TaskDetailsScreen} options={{ title: 'Detalhes' }} />
    </Stack.Navigator>
  );
}

export default AppTabs;
