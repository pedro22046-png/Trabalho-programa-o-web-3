import { useEffect, useMemo, useState } from 'react';
import { View, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity, Text, TextInput } from 'react-native';
import { useIsFocused } from '@react-navigation/native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import useTasks from '../hooks/useTasks';
import useProximityAlerts from '../hooks/useProximityAlerts';
import TaskCard from '../components/TaskCard';
import FilterBar from '../components/FilterBar';
import EmptyState from '../components/EmptyState';
import { useAuth } from '../contexts/AuthContext';
import { getCorPrioridade } from '../utils/priorities';

const DEFAULT_REGION = {
  latitude: -23.55052,
  longitude: -46.633308,
  latitudeDelta: 0.08,
  longitudeDelta: 0.08,
};

const RAIO_STORAGE_KEY = 'raio_alerta_metros';
const RAIO_PADRAO = 200;

function HomeScreen({ navigation }: any) {
  const { tasks, loading, refreshing, loadTasks, refresh, filteredTasks, setPriorityFilter, priorityFilter, statusFilter, setStatusFilter, deleteTask, toggleTaskCompleted } = useTasks();
  const isFocused = useIsFocused();
  const { signOut } = useAuth();
  const [region, setRegion] = useState(DEFAULT_REGION);

  // Raio de alerta configurável pelo usuário (persistido no aparelho).
  const [raioMetros, setRaioMetros] = useState<number>(RAIO_PADRAO);
  const [raioTexto, setRaioTexto] = useState<string>(String(RAIO_PADRAO));

  // Monitora proximidade enquanto o app está aberto e notifica ao chegar perto.
  useProximityAlerts(tasks, raioMetros, true);

  useEffect(() => {
    if (isFocused) loadTasks();
  }, [isFocused, loadTasks]);

  useEffect(() => {
    // Carrega o raio salvo (se existir).
    const carregarRaio = async () => {
      const salvo = await AsyncStorage.getItem(RAIO_STORAGE_KEY);
      if (salvo) {
        const n = parseInt(salvo, 10);
        if (!Number.isNaN(n)) {
          setRaioMetros(n);
          setRaioTexto(String(n));
        }
      }
    };
    carregarRaio();
  }, []);

  useEffect(() => {
    const initializeLocation = async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;

      const currentPosition = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setRegion({
        latitude: currentPosition.coords.latitude,
        longitude: currentPosition.coords.longitude,
        latitudeDelta: 0.04,
        longitudeDelta: 0.04,
      });
    };

    initializeLocation();
  }, []);

  const handleAlterarRaio = (texto: string) => {
    setRaioTexto(texto);
    const n = parseInt(texto, 10);
    if (!Number.isNaN(n) && n > 0) {
      setRaioMetros(n);
      AsyncStorage.setItem(RAIO_STORAGE_KEY, String(n)).catch(() => {});
    }
  };

  const handleEdit = (task: any) => {
    navigation.navigate('TaskForm', { task });
  };

  const handleDelete = async (id: string) => {
    await deleteTask(id);
  };

  const handleToggle = async (id: string, completed: boolean) => {
    await toggleTaskCompleted(id, completed);
  };

  const taskMarkers = useMemo(() => tasks.filter(task => task.latitude != null && task.longitude != null), [tasks]);

  const filtrosAtivos = priorityFilter !== 'todas' || statusFilter !== 'todos';
  const mensagemVazia = filtrosAtivos
    ? 'Nenhuma tarefa para esse filtro. Toque em "Todas" e "Todos" para ver todas.'
    : 'Nenhuma tarefa ainda. Toque no botão + para criar a primeira.';

  return (
    <View style={styles.container}>
      <FilterBar
        priorityFilter={priorityFilter}
        setPriorityFilter={setPriorityFilter}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" />
        </View>
      ) : (
        <FlatList
          data={filteredTasks}
          keyExtractor={item => item.id}
          refreshing={refreshing}
          onRefresh={refresh}
          ListHeaderComponent={(
            <View>
              <View style={styles.mapCard}>
                <Text style={styles.mapTitle}>Mapa das tarefas</Text>
                <MapView
                  style={styles.map}
                  region={region}
                  onRegionChangeComplete={setRegion}
                  showsUserLocation
                >
                  {taskMarkers.map(task => (
                    <Marker
                      key={task.id}
                      coordinate={{ latitude: task.latitude!, longitude: task.longitude! }}
                      title={task.titulo}
                      description={task.descricao ?? undefined}
                      pinColor={getCorPrioridade(task.prioridade)}
                      onCalloutPress={() => navigation.navigate('TaskDetails', { task })}
                    />
                  ))}
                </MapView>
              </View>

              <View style={styles.raioCard}>
                <Text style={styles.raioTitle}>Alerta de proximidade</Text>
                <Text style={styles.raioHelp}>
                  Avisa quando você chega a até {raioMetros}m de uma tarefa pendente (com o app aberto).
                </Text>
                <View style={styles.raioRow}>
                  <Text style={styles.raioLabel}>Raio (metros):</Text>
                  <TextInput
                    style={styles.raioInput}
                    keyboardType="number-pad"
                    value={raioTexto}
                    onChangeText={handleAlterarRaio}
                  />
                </View>
              </View>
            </View>
          )}
          renderItem={({ item }) => (
            <TaskCard task={item} onEdit={handleEdit} onDelete={handleDelete} onToggle={handleToggle} />
          )}
          ListEmptyComponent={<EmptyState message={mensagemVazia} />}
        />
      )}

      <TouchableOpacity
        onPress={() => navigation.navigate('TaskForm')}
        style={styles.fab}
        accessibilityLabel="Criar tarefa"
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => signOut()} style={styles.logout}>
        <Text style={styles.logoutText}>Sair</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f5fb' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  mapCard: { margin: 16, marginBottom: 8, backgroundColor: '#fff', borderRadius: 12, padding: 12 },
  mapTitle: { fontSize: 16, fontWeight: '700', marginBottom: 8 },
  map: { height: 220, borderRadius: 10, overflow: 'hidden' },
  raioCard: { marginHorizontal: 16, marginBottom: 8, backgroundColor: '#fff', borderRadius: 12, padding: 12 },
  raioTitle: { fontSize: 16, fontWeight: '700' },
  raioHelp: { color: '#6b7280', fontSize: 12, marginTop: 4 },
  raioRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  raioLabel: { color: '#444', marginRight: 8 },
  raioInput: { flex: 1, borderWidth: 1, borderColor: '#e6e6e6', borderRadius: 8, paddingHorizontal: 10, height: 40 },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 30,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#2563eb',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
  },
  fabText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  logout: {
    position: 'absolute',
    left: 20,
    bottom: 30,
    backgroundColor: '#ef4444',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  logoutText: { color: '#fff' },
});

export default HomeScreen;
