import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAuth } from '../contexts/AuthContext';

type Props = NativeStackScreenProps<any>;

function showAlert(title: string, message: string) {
  if (typeof window !== 'undefined' && window.alert) {
    window.alert(`${title}\n\n${message}`);
    return;
  }
  Alert.alert(title, message);
}

function LoginScreen(props: Props) {
  const { signIn } = useAuth();
  const navigation: Props['navigation'] = props.navigation;
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const validate = () => {
    if (!email) return 'E-mail é obrigatório.';
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return 'E-mail inválido.';
    if (!password) return 'Senha é obrigatória.';
    return null;
  };

  const handleSignIn = async () => {
    const errorMsg = validate();
    if (errorMsg) return showAlert('Erro', errorMsg);

    setLoading(true);
    const result = await signIn(email.trim(), password);
    setLoading(false);

    if (result?.error) {
      console.error('Login falhou:', result.error);
      const message = result.error?.message || JSON.stringify(result.error) || 'Falha ao autenticar.';
      return showAlert('Erro', message);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.logo}>RotinaApp</Text>

        <TextInput
          placeholder="E-mail"
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
        />

        <TextInput
          placeholder="Senha"
          secureTextEntry
          style={styles.input}
          value={password}
          onChangeText={setPassword}
        />

        <TouchableOpacity style={styles.button} onPress={handleSignIn} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Entrando...' : 'Entrar'}</Text>
        </TouchableOpacity>

        <Text style={styles.or}>ou</Text>

        <TouchableOpacity onPress={() => navigation.navigate('Register')}>
          <Text style={styles.linkText}>Criar uma conta</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f2f5fb' },
  card: {
    width: '90%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
    alignItems: 'center',
  },
  logo: { fontSize: 28, fontWeight: '700', marginBottom: 16 },
  input: {
    width: '100%',
    height: 44,
    borderColor: '#e6e6e6',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    marginTop: 12,
  },
  button: {
    width: '100%',
    height: 44,
    backgroundColor: '#2563eb',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  buttonText: { color: '#fff', fontWeight: '600' },
  or: { marginTop: 12, color: '#666' },
  linkText: { color: '#2563eb', marginTop: 8 },
});

export default LoginScreen;
