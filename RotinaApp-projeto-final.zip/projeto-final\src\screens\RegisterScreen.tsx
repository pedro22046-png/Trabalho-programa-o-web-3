import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAuth } from '../contexts/AuthContext';

type Props = NativeStackScreenProps<any>;

function showAlert(title: string, message: string) {
  if (typeof window !== 'undefined' && window.alert) {
    window.alert(`${title}\n\n${message}`);
    return;
  }
  Alert.alert(title, message);
}

function RegisterScreen(props: Props) {
  const { signUp } = useAuth();
  const navigation: Props['navigation'] = props.navigation;
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const validate = () => {
    if (!name) return 'Nome é obrigatório.';
    if (!email) return 'E-mail é obrigatório.';
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return 'E-mail inválido.';
    if (!password) return 'Senha é obrigatória.';
    if (password.length < 6) return 'Senha deve ter ao menos 6 caracteres.';
    if (password !== confirmPassword) return 'As senhas devem ser iguais.';
    return null;
  };

  const handleSignUp = async () => {
    const errorMsg = validate();
    if (errorMsg) return showAlert('Erro', errorMsg);

    setLoading(true);
    const result = await signUp(name.trim(), email.trim(), password);
    setLoading(false);

    if (result?.error) {
      console.error('Registro falhou:', result.error);
      const message = result.error?.message || JSON.stringify(result.error) || 'Falha ao cadastrar.';
      return showAlert('Erro', message);
    }

    showAlert('Sucesso', 'Cadastro realizado. Verifique seu e-mail se necessário.');
    navigation.navigate('Login');
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.logo}>RotinaApp</Text>

        <TextInput placeholder="Nome" style={styles.input} value={name} onChangeText={setName} />
        <TextInput
          placeholder="E-mail"
          keyboardType="email-address"
          autoCapitalize="none"
          style={styles.input}
          value={email}
          onChangeText={setEmail}
        />
        <TextInput placeholder="Senha" secureTextEntry style={styles.input} value={password} onChangeText={setPassword} />
        <TextInput
          placeholder="Confirmar Senha"
          secureTextEntry
          style={styles.input}
          value={confirmPassword}
          onChangeText={setConfirmPassword}
        />

        <TouchableOpacity style={styles.button} onPress={handleSignUp} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Cadastrando...' : 'Criar Conta'}</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Login')} style={{ marginTop: 12 }}>
          <Text style={{ color: '#2563eb' }}>Voltar para Login</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f2f5fb' },
  card: {
    width: '90%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
    alignItems: 'center',
  },
  logo: { fontSize: 28, fontWeight: '700', marginBottom: 16 },
  input: {
    width: '100%',
    height: 44,
    borderColor: '#e6e6e6',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 12,
    marginTop: 12,
  },
  button: {
    width: '100%',
    height: 44,
    backgroundColor: '#2563eb',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  buttonText: { color: '#fff', fontWeight: '600' },
});

export default RegisterScreen;
