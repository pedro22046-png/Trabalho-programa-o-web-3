import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { Task } from '../types/Task';
import * as taskService from '../services/taskService';

function TaskDetailsScreen({ navigation, route }: any) {
  const task: Task = route.params?.task;

  if (!task) {
    return (
      <View style={styles.container}>
        <Text>Tarefa não encontrada.</Text>
      </View>
    );
  }

  const hasLocation = task.latitude != null && task.longitude != null;

  const handleDelete = () => {
    Alert.alert('Confirmar', 'Deseja realmente excluir esta tarefa?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: async () => {
          const { error } = await taskService.deleteTask(task.id);
          if (error) {
            Alert.alert('Erro ao excluir tarefa', error.message || String(error));
            return;
          }
          navigation.navigate('Home');
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>{task.titulo}</Text>
        {task.descricao ? <Text style={styles.desc}>{task.descricao}</Text> : null}

        <Text style={styles.meta}>Prioridade: {task.prioridade}</Text>
        <Text style={styles.meta}>Concluída: {task.concluida ? 'Sim' : 'Não'}</Text>
        <Text style={styles.meta}>Criado em: {new Date(task.created_at).toLocaleString()}</Text>

        {hasLocation ? (
          <View style={styles.mapCard}>
            <Text style={styles.label}>Localização</Text>
            <MapView
              style={styles.map}
              initialRegion={{
                latitude: task.latitude!,
                longitude: task.longitude!,
                latitudeDelta: 0.02,
                longitudeDelta: 0.02,
              }}
            >
              <Marker coordinate={{ latitude: task.latitude!, longitude: task.longitude! }} title={task.titulo} />
            </MapView>
            {task.nome_local ? <Text style={styles.meta}>Local: {task.nome_local}</Text> : null}
            <Text style={styles.meta}>Coordenadas: {task.latitude}, {task.longitude}</Text>
          </View>
        ) : (
          <Text style={styles.meta}>Esta tarefa ainda não possui localização definida.</Text>
        )}

        <View style={styles.actions}>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('TaskForm', { task })}>
            <Text style={styles.buttonText}>Editar</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.button, { backgroundColor: '#ef4444' }]} onPress={handleDelete}>
            <Text style={styles.buttonText}>Excluir</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f5fb' },
  card: { margin: 16, backgroundColor: '#fff', padding: 16, borderRadius: 10 },
  title: { fontSize: 20, fontWeight: '700' },
  desc: { marginTop: 8, color: '#666' },
  meta: { marginTop: 6, color: '#444' },
  label: { fontWeight: '700', marginTop: 8 },
  mapCard: { marginTop: 12 },
  map: { height: 220, marginTop: 8, borderRadius: 10, overflow: 'hidden' },
  actions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 16 },
  button: { flex: 1, backgroundColor: '#2563eb', padding: 12, borderRadius: 8, alignItems: 'center', marginHorizontal: 6 },
  buttonText: { color: '#fff', fontWeight: '700' },
});

export default TaskDetailsScreen;
