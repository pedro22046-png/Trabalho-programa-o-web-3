import { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { useAuth } from '../contexts/AuthContext';
import { Task } from '../types/Task';
import * as taskService from '../services/taskService';

const DEFAULT_REGION = {
  latitude: -23.55052,
  longitude: -46.633308,
  latitudeDelta: 0.08,
  longitudeDelta: 0.08,
};

function showAlert(title: string, message: string) {
  if (typeof window !== 'undefined' && window.alert) {
    window.alert(`${title}\n\n${message}`);
    return;
  }
  Alert.alert(title, message);
}

function TaskFormScreen({ navigation, route }: any) {
  const { user } = useAuth();
  const task: Task | undefined = route.params?.task;
  const [titulo, setTitulo] = useState(task?.titulo ?? '');
  const [descricao, setDescricao] = useState(task?.descricao ?? '');
  const [prioridade, setPrioridade] = useState<Task['prioridade']>(task?.prioridade ?? 'media');
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(
    task?.latitude != null && task?.longitude != null ? { latitude: task.latitude, longitude: task.longitude } : null,
  );
  const [locationName, setLocationName] = useState(task?.nome_local ?? '');
  const [region, setRegion] = useState(DEFAULT_REGION);
  const [permissionHint, setPermissionHint] = useState<string | null>(null);

  useEffect(() => {
    navigation.setOptions({ title: task ? 'Editar Tarefa' : 'Nova Tarefa' });

    const initializeLocation = async () => {
      const existingLocation = task?.latitude != null && task?.longitude != null
        ? { latitude: task.latitude, longitude: task.longitude }
        : null;

      if (existingLocation) {
        setLocation(existingLocation);
        setRegion({ ...existingLocation, latitudeDelta: 0.02, longitudeDelta: 0.02 });
        return;
      }

      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setPermissionHint('Permissão de localização negada. Você pode continuar sem definir um ponto no mapa.');
        return;
      }

      const currentPosition = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const userLocation = {
        latitude: currentPosition.coords.latitude,
        longitude: currentPosition.coords.longitude,
      };
      setLocation(userLocation);
      setRegion({ ...userLocation, latitudeDelta: 0.02, longitudeDelta: 0.02 });
    };

    initializeLocation();
  }, [navigation, task]);

  const validate = () => {
    if (!titulo.trim()) return 'Título é obrigatório.';
    if (!prioridade) return 'Prioridade é obrigatória.';
    return null;
  };

  const handleSave = async () => {
    const err = validate();
    if (err) return Alert.alert('Erro', err);

    setLoading(true);
    try {
      const payload: Record<string, any> = {
        titulo: titulo.trim(),
        descricao: descricao.trim(),
        prioridade,
        concluida: false,
      };

      if (location) {
        payload.latitude = location.latitude;
        payload.longitude = location.longitude;
        payload.nome_local = locationName.trim() || null;
      }

      if (user?.id) payload.user_id = user.id;

      if (task) {
        const { error } = await taskService.updateTask(task.id, payload);
        if (error) {
          console.error('Erro ao atualizar tarefa', error);
          showAlert('Erro ao atualizar tarefa', error.message || String(error));
        } else {
          navigation.goBack();
        }
      } else {
        const { error } = await taskService.createTask(payload);
        if (error) {
          console.error('Erro ao criar tarefa', error);
          showAlert('Erro ao criar tarefa', error.message || String(error));
        } else {
          navigation.goBack();
        }
      }
    } catch (err: any) {
      console.error('Exceção ao salvar tarefa', err);
      showAlert('Erro', err.message || String(err));
    } finally {
      setLoading(false);
    }
  };

  const handleLocationSelect = (coordinate: { latitude: number; longitude: number }) => {
    setLocation(coordinate);
    setRegion(prev => ({ ...prev, latitude: coordinate.latitude, longitude: coordinate.longitude }));
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.label}>Título</Text>
        <TextInput style={styles.input} value={titulo} onChangeText={setTitulo} />

        <Text style={styles.label}>Descrição</Text>
        <TextInput style={[styles.input, { height: 80 }]} value={descricao ?? ''} onChangeText={setDescricao} multiline />

        <Text style={styles.label}>Prioridade</Text>
        <View style={styles.pickerWrap}>
          <View style={styles.priorityRow}>
            <TouchableOpacity
              style={[styles.priorityBtn, prioridade === 'alta' ? styles.priorityActive : null]}
              onPress={() => setPrioridade('alta')}
            >
              <Text style={prioridade === 'alta' ? styles.priorityTextActive : styles.priorityText}>Alta</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.priorityBtn, prioridade === 'media' ? styles.priorityActive : null]}
              onPress={() => setPrioridade('media')}
            >
              <Text style={prioridade === 'media' ? styles.priorityTextActive : styles.priorityText}>Média</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.priorityBtn, prioridade === 'baixa' ? styles.priorityActive : null]}
              onPress={() => setPrioridade('baixa')}
            >
              <Text style={prioridade === 'baixa' ? styles.priorityTextActive : styles.priorityText}>Baixa</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Text style={styles.label}>Localização</Text>
        {permissionHint ? <Text style={styles.helper}>{permissionHint}</Text> : null}
        <MapView
          style={styles.map}
          region={region}
          onRegionChangeComplete={setRegion}
          onPress={(event) => handleLocationSelect(event.nativeEvent.coordinate)}
          showsUserLocation
        >
          {location ? (
            <Marker
              draggable
              coordinate={location}
              onDragEnd={(event) => handleLocationSelect(event.nativeEvent.coordinate)}
            />
          ) : null}
        </MapView>

        <TextInput
          style={styles.input}
          value={locationName}
          onChangeText={setLocationName}
          placeholder="Nome do local (opcional)"
        />

        <TouchableOpacity style={styles.button} onPress={handleSave} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Salvando...' : 'Salvar'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f5fb' },
  card: { margin: 16, backgroundColor: '#fff', padding: 16, borderRadius: 10 },
  label: { fontWeight: '700', marginTop: 8 },
  input: { borderWidth: 1, borderColor: '#e6e6e6', borderRadius: 8, paddingHorizontal: 10, height: 44, marginTop: 8 },
  pickerWrap: { borderWidth: 1, borderColor: '#e6e6e6', borderRadius: 8, marginTop: 8 },
  priorityRow: { flexDirection: 'row', justifyContent: 'space-between' },
  priorityBtn: { flex: 1, paddingVertical: 10, alignItems: 'center' },
  priorityActive: { backgroundColor: '#2563eb', borderRadius: 8 },
  priorityText: { color: '#333' },
  priorityTextActive: { color: '#fff', fontWeight: '700' },
  helper: { marginTop: 6, color: '#6b7280', fontSize: 12 },
  map: { height: 220, marginTop: 8, borderRadius: 10, overflow: 'hidden' },
  button: { marginTop: 16, backgroundColor: '#2563eb', height: 44, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700' },
});

export default TaskFormScreen;
