import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

// Serviço de notificações locais (SDK 54).
// Obs.: notificações LOCAIS funcionam no Expo Go; apenas push remoto não funciona.

// Handler global: define como a notificação aparece quando o app está ABERTO.
// No SDK 54 os campos são shouldShowBanner/shouldShowList (não mais shouldShowAlert).
export function configurarNotificacoes() {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

// Pede permissão e cria o canal no Android. Retorna true se pode notificar.
export async function pedirPermissaoNotificacoes(): Promise<boolean> {
  try {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('proximidade', {
        name: 'Alertas de proximidade',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
      });
    }
    const { status } = await Notifications.requestPermissionsAsync();
    return status === 'granted';
  } catch (erro) {
    console.warn('Erro ao pedir permissão de notificação', erro);
    return false;
  }
}

// Dispara uma notificação local imediata (trigger: null = agora).
export async function notificarProximidade(titulo: string, nomeLocal?: string | null) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Você está perto de uma tarefa! 📍',
        body: nomeLocal ? `${titulo} — ${nomeLocal}` : titulo,
        sound: true,
      },
      trigger: null,
    });
  } catch (erro) {
    console.warn('Erro ao enviar notificação', erro);
  }
}
