import 'react-native-url-polyfill/auto';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Configuração do Supabase.
// Em produção você pode usar variáveis de ambiente (prefixo EXPO_PUBLIC_ no Expo),
// mas os valores abaixo já funcionam direto para desenvolvimento.
const SUPABASE_URL =
	process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://uxjxbzwfqdikdtpcmxup.supabase.co';
const SUPABASE_ANON_KEY =
	process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
	'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV4anhiendmcWRpa2R0cGNteHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE1NTM4NTcsImV4cCI6MjA5NzEyOTg1N30.-SSnHw2QlgV-EbOv0RWyJgZRexLyYquykMfiYVpHciw';

// IMPORTANTE (React Native / Expo): sem `storage: AsyncStorage` a sessão do
// login não fica salva no aparelho. O usuário parece logado, mas o cliente
// perde o token ao reabrir o app e o banco passa a recusar as consultas (RLS).
export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
	auth: {
		storage: AsyncStorage,
		autoRefreshToken: true,
		persistSession: true,
		detectSessionInUrl: false,
	},
});

export default supabase;
