import supabase from './supabase';
import { Task } from '../types/Task';

// Serviço de CRUD da tabela `tarefas`.
// Todas as funções retornam um objeto com `data` e `error`, como o Supabase.

export const getTasks = async (): Promise<{ data: Task[] | null; error: any }> => {
  const { data, error } = await supabase
    .from('tarefas')
    .select('*')
    .order('created_at', { ascending: false });
  return { data: (data as Task[]) ?? null, error };
};

export const createTask = async (
  payload: Omit<Partial<Task>, 'id' | 'created_at'>,
): Promise<{ data: Task | null; error: any }> => {
  const { data, error } = await supabase
    .from('tarefas')
    .insert([payload])
    .select()
    .single();
  return { data: (data as Task) ?? null, error };
};

export const updateTask = async (
  id: string,
  payload: Partial<Task>,
): Promise<{ data: Task | null; error: any }> => {
  const { data, error } = await supabase
    .from('tarefas')
    .update(payload)
    .eq('id', id)
    .select()
    .single();
  return { data: (data as Task) ?? null, error };
};

export const deleteTask = async (id: string): Promise<{ data: Task | null; error: any }> => {
  const { data, error } = await supabase
    .from('tarefas')
    .delete()
    .eq('id', id)
    .select()
    .single();
  return { data: (data as Task) ?? null, error };
};

export const toggleTaskCompleted = async (
  id: string,
  completed: boolean,
): Promise<{ data: Task | null; error: any }> => {
  const { data, error } = await supabase
    .from('tarefas')
    .update({ concluida: completed })
    .eq('id', id)
    .select()
    .single();
  return { data: (data as Task) ?? null, error };
};

export default {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
  toggleTaskCompleted,
};
