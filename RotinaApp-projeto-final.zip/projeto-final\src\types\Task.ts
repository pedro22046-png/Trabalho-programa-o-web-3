export type Priority = 'alta' | 'media' | 'baixa';

export interface Task {
  id: string;
  user_id: string;
  titulo: string;
  descricao: string | null;
  prioridade: Priority;
  concluida: boolean;
  latitude?: number | null;
  longitude?: number | null;
  nome_local?: string | null;
  created_at: string;
}
