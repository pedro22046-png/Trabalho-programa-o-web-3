// Calcula a distância em METROS entre duas coordenadas (fórmula de Haversine).
// O Expo Location não traz uma função pronta para isso, então fazemos aqui.
export function distanciaEmMetros(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const R = 6371000; // raio médio da Terra, em metros
  const paraRad = (graus: number) => (graus * Math.PI) / 180;

  const dLat = paraRad(lat2 - lat1);
  const dLon = paraRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(paraRad(lat1)) * Math.cos(paraRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
