import { Priority } from '../types/Task';

// Cores e rótulos de prioridade centralizados em um só lugar.
// Usado no selo (badge), nos pins do mapa e no formulário.
export const PRIORIDADES: Record<Priority, { label: string; cor: string }> = {
  alta: { label: 'Alta', cor: '#ef4444' },
  media: { label: 'Média', cor: '#f59e0b' },
  baixa: { label: 'Baixa', cor: '#10b981' },
};

export function getCorPrioridade(prioridade: Priority): string {
  return PRIORIDADES[prioridade]?.cor ?? '#6b7280';
}

export function getRotuloPrioridade(prioridade: Priority): string {
  return PRIORIDADES[prioridade]?.label ?? prioridade;
}
