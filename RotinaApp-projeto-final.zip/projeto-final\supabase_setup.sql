-- ============================================================
-- RotinaApp — Configuração do banco de dados (Supabase)
--
-- COMO USAR:
--   1. Abra o painel do Supabase do seu projeto
--   2. Menu lateral → "SQL Editor" → "New query"
--   3. Cole TODO este arquivo e clique em "Run"
--
-- Pode rodar quantas vezes quiser: o script é seguro para repetir.
-- ============================================================

-- 1) Tabela de tarefas (cria só se ainda não existir)
create table if not exists public.tarefas (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  titulo      text not null,
  descricao   text,
  prioridade  text not null default 'media' check (prioridade in ('alta', 'media', 'baixa')),
  concluida   boolean not null default false,
  latitude    double precision,
  longitude   double precision,
  nome_local  text,
  created_at  timestamptz not null default now()
);

-- Garante todas as colunas mesmo que a tabela já existisse de antes
alter table public.tarefas add column if not exists user_id     uuid default auth.uid();
alter table public.tarefas add column if not exists titulo      text;
alter table public.tarefas add column if not exists descricao   text;
alter table public.tarefas add column if not exists prioridade  text default 'media';
alter table public.tarefas add column if not exists concluida   boolean default false;
alter table public.tarefas add column if not exists latitude    double precision;
alter table public.tarefas add column if not exists longitude   double precision;
alter table public.tarefas add column if not exists nome_local  text;
alter table public.tarefas add column if not exists created_at  timestamptz default now();

-- 2) Liga o RLS (Row Level Security): sem isso, ninguém acessa nada com a chave anon
alter table public.tarefas enable row level security;

-- 3) Políticas: cada usuário só vê e mexe nas PRÓPRIAS tarefas
drop policy if exists "tarefas_select_own" on public.tarefas;
create policy "tarefas_select_own" on public.tarefas
  for select using (auth.uid() = user_id);

drop policy if exists "tarefas_insert_own" on public.tarefas;
create policy "tarefas_insert_own" on public.tarefas
  for insert with check (auth.uid() = user_id);

drop policy if exists "tarefas_update_own" on public.tarefas;
create policy "tarefas_update_own" on public.tarefas
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "tarefas_delete_own" on public.tarefas;
create policy "tarefas_delete_own" on public.tarefas
  for delete using (auth.uid() = user_id);

-- Pronto! A tabela `tarefas` está criada e protegida por usuário.
