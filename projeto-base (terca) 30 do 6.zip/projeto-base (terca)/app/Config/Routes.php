<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// API Routes
$routes->get('api/produtos', 'Api::produtos');
$routes->post('api/pedidos', 'Api::criarPedido');
$routes->get('api/cozinha/pedidos', 'Api::listaPedidos');
$routes->get('api/cozinha/pedidos/(:num)', 'Api::detalhePedido/$1');
$routes->put('api/cozinha/pedidos/(:num)/status', 'Api::atualizarStatusPedido/$1');
