<?php

namespace App\Controllers;

use CodeIgniter\HTTP\ResponseInterface;

class Api extends BaseController
{
    /**
     * Lista todos os produtos disponíveis
     */
    public function produtos(): ResponseInterface
    {
        $produtos = [
            [
                'id' => 1,
                'nome' => 'Desert Eagle',
                'descricao' => 'Pistola de alto calibre com mira precisa.',
                'preco' => 1520,
                'categoria' => 'Pistola',
                'imagem' => 'assets/imagens/desert-eagle.svg',
            ],
            [
                'id' => 2,
                'nome' => 'AK-47',
                'descricao' => 'Rifle robusto para operações rápidas.',
                'preco' => 2400,
                'categoria' => 'Rifle',
                'imagem' => 'assets/imagens/ak47.svg',
            ],
            [
                'id' => 3,
                'nome' => 'M4A1',
                'descricao' => 'Rifle leve com excelente controle.',
                'preco' => 2750,
                'categoria' => 'Rifle',
                'imagem' => 'assets/imagens/m4a1.svg',
            ],
            [
                'id' => 4,
                'nome' => 'Glock 19',
                'descricao' => 'Pistola compacta para uso tático.',
                'preco' => 1280,
                'categoria' => 'Pistola',
                'imagem' => 'assets/imagens/glock19.svg',
            ],
            [
                'id' => 5,
                'nome' => 'Coletes',
                'descricao' => 'Proteção leve para operações em campo.',
                'preco' => 720,
                'categoria' => 'Acessório',
                'imagem' => 'assets/imagens/coletes.svg',
            ],
            [
                'id' => 6,
                'nome' => 'Munição 9mm',
                'descricao' => 'Cartuchos de uso geral para pistolas.',
                'preco' => 230,
                'categoria' => 'Acessório',
                'imagem' => 'assets/imagens/municao-9mm.svg',
            ],
        ];

        return $this->response->setJSON($produtos);
    }

    /**
     * Cria um novo pedido
     */
    public function criarPedido(): ResponseInterface
    {
        $this->response->setHeader('Content-Type', 'application/json');

        // Validar que a requisição é POST
        if ($this->request->getMethod() !== 'post') {
            return $this->response
                ->setStatusCode(405)
                ->setJSON(['erro' => 'Método não permitido']);
        }

        // Obter dados da requisição
        $json = $this->request->getJSON();

        // Validar que há itens
        if (!isset($json->itens) || empty($json->itens)) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['erro' => 'Pedido sem itens']);
        }

        // Gerar número do pedido
        $numeroPedido = str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

        // Calcular total
        $total = 0;
        foreach ($json->itens as $item) {
            $total += ($item->preco ?? 0) * ($item->quantidade ?? 0);
        }

        // Preparar resposta
        $pedido = [
            'id' => $numeroPedido,
            'numero' => $numeroPedido,
            'data' => date('Y-m-d H:i:s'),
            'itens' => $json->itens,
            'total' => $total,
            'status' => 'recebido',
        ];

        // Armazenar o pedido em sessão
        $pedidos = session()->get('pedidos') ?? [];
        $pedidos[$numeroPedido] = $pedido;
        session()->set('pedidos', $pedidos);

        return $this->response
            ->setStatusCode(201)
            ->setJSON($pedido);
    }

    /**
     * Lista todos os pedidos
     */
    public function listaPedidos(): ResponseInterface
    {
        $pedidos = session()->get('pedidos') ?? [];
        $pedidosArray = array_values($pedidos);

        // Ordenar por data descendente (mais recentes primeiro)
        usort($pedidosArray, function ($a, $b) {
            return strtotime($b['data']) - strtotime($a['data']);
        });

        return $this->response->setJSON($pedidosArray);
    }

    /**
     * Obtém detalhes de um pedido específico
     */
    public function detalhePedido($id = null): ResponseInterface
    {
        if (!$id) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['erro' => 'ID do pedido não fornecido']);
        }

        $pedidos = session()->get('pedidos') ?? [];

        if (!isset($pedidos[$id])) {
            return $this->response
                ->setStatusCode(404)
                ->setJSON(['erro' => 'Pedido não encontrado']);
        }

        return $this->response->setJSON($pedidos[$id]);
    }

    /**
     * Atualiza o status de um pedido
     */
    public function atualizarStatusPedido($id = null): ResponseInterface
    {
        $this->response->setHeader('Content-Type', 'application/json');

        if (!$id) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['erro' => 'ID do pedido não fornecido']);
        }

        $json = $this->request->getJSON();

        if (!isset($json->status)) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['erro' => 'Status não fornecido']);
        }

        $pedidos = session()->get('pedidos') ?? [];

        if (!isset($pedidos[$id])) {
            return $this->response
                ->setStatusCode(404)
                ->setJSON(['erro' => 'Pedido não encontrado']);
        }

        // Atualizar status
        $pedidos[$id]['status'] = $json->status;
        session()->set('pedidos', $pedidos);

        return $this->response->setJSON($pedidos[$id]);
    }
}
