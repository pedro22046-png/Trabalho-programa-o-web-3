const CART_KEY = 'pedido-cart';
const cartItemsContainer = document.getElementById('cart-items');
const cartTotalValue = document.getElementById('cart-final-total');
const cartTotalFooter = document.getElementById('cart-final-total-footer');
const messageBox = document.getElementById('message-box');
const cancelBtn = document.getElementById('cancel-btn');
const viewReceiptBtn = document.getElementById('view-receipt-btn');

window.addEventListener('DOMContentLoaded', renderCart);
cancelBtn.addEventListener('click', handleCancel);
viewReceiptBtn.addEventListener('click', handleViewReceipt);
cartItemsContainer.addEventListener('click', handleCartAction);

function getCart() {
  return JSON.parse(localStorage.getItem(CART_KEY) || '[]');
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function renderCart() {
  const cart = getCart();
  if (!cart.length) {
    cartItemsContainer.innerHTML = '<p>Seu carrinho está vazio. Volte para a tela de produtos e adicione itens.</p>';
    cartTotalValue.textContent = Utils.formatCurrency(0);
    cartTotalFooter.textContent = Utils.formatCurrency(0);
    viewReceiptBtn.disabled = true;
    return;
  }

  viewReceiptBtn.disabled = false;
  const cards = cart
    .map((item) => {
      const image = item.imagem || 'https://via.placeholder.com/180x120?text=Imagem';
      return `
        <article class="cart-item">
          <img src="${image}" alt="${item.nome}" />
          <div class="cart-item-details">
            <div class="cart-item-info">
              <div>
                <h3 class="cart-item-name">${item.nome}</h3>
                <p>Unitário: ${Utils.formatCurrency(item.preco)}</p>
              </div>
              <button class="remove-btn" data-action="remove" data-id="${item.id}">X</button>
            </div>
            <div class="quantity-controls">
              <button class="quantity-btn" data-action="decrease" data-id="${item.id}">-</button>
              <span>${item.quantidade}</span>
              <button class="quantity-btn" data-action="increase" data-id="${item.id}">+</button>
              <strong class="cart-item-price">${Utils.formatCurrency(item.preco * item.quantidade)}</strong>
            </div>
          </div>
        </article>
      `;
    })
    .join('');

  cartItemsContainer.innerHTML = cards;
  updateTotal(cart);
}

function updateTotal(cart) {
  const total = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  cartTotalValue.textContent = Utils.formatCurrency(total);
  cartTotalFooter.textContent = Utils.formatCurrency(total);
}

function handleCartAction(event) {
  const actionButton = event.target.closest('[data-action]');
  if (!actionButton) return;

  const action = actionButton.dataset.action;
  const productId = Number(actionButton.dataset.id);

  if (action === 'increase') {
    changeQuantity(productId, 1);
  } else if (action === 'decrease') {
    changeQuantity(productId, -1);
  } else if (action === 'remove') {
    removeFromCart(productId);
  }
}

function changeQuantity(productId, delta) {
  const cart = getCart();
  const item = cart.find((entry) => entry.id === productId);
  if (!item) return;

  item.quantidade += delta;
  if (item.quantidade <= 0) {
    removeFromCart(productId);
    return;
  }

  saveCart(cart);
  renderCart();
}

function removeFromCart(productId) {
  const cart = getCart().filter((item) => item.id !== productId);
  saveCart(cart);
  renderCart();
}

function handleCancel() {
  localStorage.removeItem(CART_KEY);
  window.location.href = 'index.html';
}

function handleViewReceipt() {
  const cart = getCart();
  if (!cart.length) {
    Utils.showMessage(messageBox, 'Adicione produtos ao carrinho antes de visualizar a nota.', 'error');
    return;
  }

  const total = cart.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  const numeroPedido = Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, '0');

  localStorage.setItem('pedido-final', JSON.stringify({
    numero: numeroPedido,
    itens: cart,
    total: total,
  }));

  window.location.href = 'pedido.html';
}
