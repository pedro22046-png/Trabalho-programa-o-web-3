const orderSummary = document.getElementById('order-summary');
const checkoutTotal = document.getElementById('checkout-total');
const finishBtn = document.getElementById('finish-btn');

window.addEventListener('DOMContentLoaded', initCheckout);
finishBtn.addEventListener('click', () => {
  // Limpar localStorage ao clicar em "Finalizar Pedido"
  localStorage.removeItem('pedido-final');
  localStorage.removeItem('pedido-cart');
  window.location.href = 'index.html';
});

function initCheckout() {
  const finalOrder = JSON.parse(localStorage.getItem('pedido-final') || 'null');
  if (!finalOrder || !finalOrder.itens) {
    window.location.href = 'produtos.html';
    return;
  }

  orderSummary.innerHTML = finalOrder.itens
    .map(
      (item) => `
      <div class="order-row">
        <div class="order-definition">
          <strong>${item.quantidade}x ${item.nome}</strong>
          <span>Unitário: ${Utils.formatCurrency(item.preco)}</span>
        </div>
        <strong>${Utils.formatCurrency(item.preco * item.quantidade)}</strong>
      </div>`
    )
    .join('');

  // Usar o total já calculado que veio do localStorage
  const total = finalOrder.total || finalOrder.itens.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  checkoutTotal.textContent = Utils.formatCurrency(total);
}
