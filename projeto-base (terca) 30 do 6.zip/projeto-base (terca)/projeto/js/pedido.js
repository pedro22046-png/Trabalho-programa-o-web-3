const RECEIPT_KEY = 'pedido-final';
const CART_KEY = 'pedido-cart';
const receiptCard = document.getElementById('receipt-card');
const confirmOrderBtn = document.getElementById('confirm-order-btn');

window.addEventListener('DOMContentLoaded', renderReceipt);
confirmOrderBtn.addEventListener('click', handleConfirmOrder);

function renderReceipt() {
  const order = JSON.parse(localStorage.getItem(RECEIPT_KEY) || 'null');
  if (!order) {
    window.location.href = 'index.html';
    return;
  }

  const itemsHtml = order.itens
    .map(
      (item) => `
      <div class="receipt-item">
        <span>${item.quantidade}x ${item.nome}</span>
        <span>${Utils.formatCurrency(item.preco)}</span>
      </div>`
    )
    .join('');

  receiptCard.innerHTML = `
    <div class="order-definition">
      <span class="order-number">Pedido Nº ${order.numero}</span>
      <strong>Total: ${Utils.formatCurrency(order.total)}</strong>
    </div>
    ${itemsHtml}`;
}

function handleConfirmOrder() {
  const order = JSON.parse(localStorage.getItem(RECEIPT_KEY) || 'null');
  if (!order) {
    window.location.href = 'index.html';
    return;
  }

  // Ir para tela de agradecimento (checkout)
  window.location.href = 'checkout.html';
}
